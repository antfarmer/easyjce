/*
 * Copyright 2006-2007 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.antfarmer.ejce;

import java.security.GeneralSecurityException;
import java.security.Key;
import java.security.MessageDigest;
import java.security.spec.AlgorithmParameterSpec;

import javax.crypto.Cipher;
import javax.crypto.Mac;

import org.antfarmer.ejce.parameter.AlgorithmParameters;


/**
 * Abstract class for encrypting/decrypting byte arrays.
 *
 * @author Ameer Antar
 * @version 1.1
 * @param <T> the concrete type of this encryptor object.
 */
public abstract class AbstractEncryptor<T extends AbstractEncryptor<T>> implements EncryptorInterface<T> {

	private boolean initialized;

	private boolean macEnabled;

	private AlgorithmParameters<?> parameters;

	private Key key;

	private Cipher encryptor;

	private Cipher decryptor;

	private Key macKey;

	private Mac encMac;

	private Mac decMac;

	/**
	 * {@inheritDoc}
	 *
	 * @throws GeneralSecurityException
	 * @see org.antfarmer.ejce.EncryptorInterface#initialize()
	 */
	public synchronized void initialize() throws GeneralSecurityException {
		if (initialized) {
			return;
		}
		if (parameters == null) {
			throw new GeneralSecurityException(
					"AlgorithmParameters must be set before initializing.");
		}
		// setup key and ciphers
		key = parameters.getKey();
		String transformation = parameters.getTransformation();
		encryptor = getCipherInstance(transformation);
		decryptor = getCipherInstance(transformation);

		// setup MAC if required
		if (parameters.getMacAlgorithm() != null && parameters.getMacKey() != null) {
			encMac = getMacInstance(parameters.getMacAlgorithm());
			decMac = getMacInstance(parameters.getMacAlgorithm());
			macKey = parameters.getMacKey();
			macEnabled = true;
		}

		initialized = true;
	}

	private Cipher getCipherInstance(String transformation)
			throws GeneralSecurityException {
		if (parameters.getProvider() != null) {
			return Cipher.getInstance(transformation, parameters.getProvider());
		}
		if (parameters.getProviderName() != null) {
			return Cipher.getInstance(transformation, parameters.getProviderName());
		}
		return Cipher.getInstance(transformation);
	}

	private Mac getMacInstance(String transformation)
			throws GeneralSecurityException {
		if (parameters.getProvider() != null) {
			return Mac.getInstance(transformation, parameters.getProvider());
		}
		if (parameters.getProviderName() != null) {
			return Mac.getInstance(transformation, parameters.getProviderName());
		}
		return Mac.getInstance(transformation);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see org.antfarmer.ejce.EncryptorInterface#encrypt(byte[])
	 */
	public byte[] encrypt(byte[] bytes) throws GeneralSecurityException {
		if (bytes == null) {
			return null;
		}
		initialize();
		int cLen;
		byte[] enciphered;
		int paramSize = parameters.getParameterSpecSize();

		synchronized (encryptor) {
			byte[] paramData = parameters.generateParameterSpecData();
			AlgorithmParameterSpec paramSpec = parameters.generateParameterSpec(paramData);
			encryptor.init(Cipher.ENCRYPT_MODE, key, paramSpec);
			if (macEnabled) {
				synchronized (encMac) {
					enciphered = new byte[encryptor.getOutputSize(bytes.length + encMac.getMacLength())
							+ paramSize];
					cLen = encryptor.update(bytes, 0, bytes.length, enciphered, 0);
					encMac.init(macKey);
					cLen += encryptor.doFinal(encMac.doFinal(bytes), 0, encMac.getMacLength(),
							enciphered, cLen);
				}
			}
			else {
				enciphered = new byte[encryptor.getOutputSize(bytes.length) + paramSize];
				cLen = encryptor.doFinal(bytes, 0, bytes.length, enciphered, 0);
			}
			if (paramSize > 0) {
				System.arraycopy(paramData, 0, enciphered, cLen, paramSize);
			}
		}

		return enciphered;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see org.antfarmer.ejce.EncryptorInterface#decrypt(byte[])
	 */
	public byte[] decrypt(byte[] bytes) throws GeneralSecurityException {
		if (bytes == null) {
			return null;
		}
		initialize();
		int inputLen = bytes.length;
		AlgorithmParameterSpec algorithmSpec = null;
		int paramSize = parameters.getParameterSpecSize();
		if (paramSize > 0) {
			inputLen -= paramSize;
			algorithmSpec = parameters.getParameterSpec(bytes);
		}
		byte[] buff;
		synchronized (decryptor) {
			decryptor.init(Cipher.DECRYPT_MODE, key, algorithmSpec);
			buff = decryptor.doFinal(bytes, 0, inputLen);
		}
		if (!macEnabled) {
			return buff;
		}

		byte[] deciphered;
		synchronized (decMac) {
			deciphered = new byte[buff.length - decMac.getMacLength()];
			byte[] rcvdMac = new byte[decMac.getMacLength()];
			System.arraycopy(buff, 0, deciphered, 0, deciphered.length);
			System.arraycopy(buff, deciphered.length, rcvdMac, 0, rcvdMac.length);

			decMac.init(macKey);
			if (!MessageDigest.isEqual(rcvdMac, decMac.doFinal(deciphered))) {
				throw new MacDisagreementException(
						"MAC disagreement. This message may have been tampered with.");
			}
		}

		return deciphered;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see org.antfarmer.ejce.EncryptorInterface#isInitialized()
	 */
	public synchronized boolean isInitialized() {
		return initialized;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see org.antfarmer.ejce.EncryptorInterface#setAlgorithmParameters(
	 * 		org.antfarmer.ejce.parameter.AlgorithmParameters)
	 */
	@SuppressWarnings("unchecked")
	public T setAlgorithmParameters(AlgorithmParameters<?> parameters) {
		this.parameters = parameters;
		return (T) this;
	}

}
