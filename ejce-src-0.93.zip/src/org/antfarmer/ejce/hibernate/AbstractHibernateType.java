/*
 * Copyright 2006-2007 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.antfarmer.ejce.hibernate;

import java.io.Serializable;
import java.security.GeneralSecurityException;
import java.security.Provider;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import org.antfarmer.ejce.Encryptor;
import org.antfarmer.ejce.EncryptorStore;
import org.antfarmer.ejce.ValueEncryptorInterface;
import org.antfarmer.ejce.encoder.Base64Encoder;
import org.antfarmer.ejce.encoder.TextEncoder;
import org.antfarmer.ejce.parameter.AbstractBlockCipherParameters;
import org.antfarmer.ejce.parameter.AlgorithmParameters;
import org.antfarmer.ejce.parameter.PbeParameters;
import org.antfarmer.ejce.util.ReflectionUtil;
import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.usertype.ParameterizedType;
import org.hibernate.usertype.UserType;
import org.hibernate.util.EqualsHelper;


/**
 * Abstract Hibernate UserType class which encrypts and decrypts values transparently. This ensures
 * data is stored in it's encrypted form in persistent storage, while not affecting it's real value
 * in the application.
 *
 * @author Ameer Antar
 * @version 1.0
 */
public abstract class AbstractHibernateType implements UserType, ParameterizedType {

	private static final int[] sqlTypes = new int[] { Hibernate.STRING.sqlType() };

	private static final String KEY_ENCRYPTOR_NAME = "encryptor";

	private static final String KEY_PARAM_CLASS = "paramClass";

	private static final String KEY_PARAM_ENCODER_CLASS = "paramEncoder";

	private static final String FIELD_TEXT_ENCODER = "textEncoder";

	private static final String KEY_ENCRYPTION_KEY = "key";

	private static final String KEY_ALGORITHM = "algorithm";

	private static final String FIELD_ALGORITHM = "algorithm";

	private static final String KEY_PROVIDER_NAME = "providerName";

	private static final String KEY_PROVIDER_CLASS = "providerClass";

	private static final String KEY_MAC_KEY = "macKey";

	private static final String KEY_MAC_ALGORITHM = "macAlgorithm";

	private static final String KEY_BLOCK_MODE = "blockMode";

	private static final String KEY_BLOCK_SIZE = "blockSize";

	private static final String KEY_PADDING = "padding";

	private static final String KEY_SALT_SIZE = "saltSize";

	private static final String KEY_ITERATION_COUNT = "iterations";

	private ValueEncryptorInterface<Encryptor> encryptor;

	/**
	 * Encrypts the given object using an appropriate method for the object type.
	 *
	 * @param value the object to be encrypted
	 * @return a string representation of the encrypted and encoded object
	 * @throws GeneralSecurityException GeneralSecurityException
	 */
	protected abstract String encrypt(Object value) throws GeneralSecurityException;

	/**
	 * Decrypts the given string using an appropriate method for the object type.
	 *
	 * @param value the string to be decrypted
	 * @return the decrypted object
	 * @throws GeneralSecurityException GeneralSecurityException
	 */
	protected abstract Object decrypt(String value) throws GeneralSecurityException;

	/**
	 * {@inheritDoc}
	 *
	 * @see org.hibernate.usertype.UserType#assemble(java.io.Serializable, java.lang.Object)
	 */
	public Object assemble(final Serializable cached, final Object owner) throws HibernateException {
		if (cached == null) {
			return null;
		}
		else {
			return deepCopy(cached);
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see org.hibernate.usertype.UserType#deepCopy(java.lang.Object)
	 */
	public Object deepCopy(final Object value) throws HibernateException {
		return value;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see org.hibernate.usertype.UserType#disassemble(java.lang.Object)
	 */
	public Serializable disassemble(final Object value) throws HibernateException {
		if (value == null) {
			return null;
		}
		else {
			return (Serializable) deepCopy(value);
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see org.hibernate.usertype.UserType#equals(java.lang.Object, java.lang.Object)
	 */
	public boolean equals(final Object x, final Object y) throws HibernateException {
		return EqualsHelper.equals(x, y);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see org.hibernate.usertype.UserType#hashCode(java.lang.Object)
	 */
	public int hashCode(final Object x) throws HibernateException {
		return x.hashCode();
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see org.hibernate.usertype.UserType#isMutable()
	 */
	public boolean isMutable() {
		return false;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see org.hibernate.usertype.UserType#nullSafeGet(java.sql.ResultSet, java.lang.String[],
	 *      java.lang.Object)
	 */
	public Object nullSafeGet(final ResultSet rs, final String[] names, final Object owner)
			throws HibernateException, SQLException {
		initializeIfNot();
		final String text = rs.getString(names[0]);
		try {
			return rs.wasNull() || text.length() < 1 ? null : decrypt(text);
		}
		catch (final GeneralSecurityException e) {
			throw new UserTypeConfigurationException("Error decrypting object.", e);
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see org.hibernate.usertype.UserType#nullSafeSet(java.sql.PreparedStatement,
	 *      java.lang.Object, int)
	 */
	public void nullSafeSet(final PreparedStatement st, final Object value, final int index)
			throws HibernateException, SQLException {
		initializeIfNot();
		if (value == null) {
			st.setNull(index, Hibernate.STRING.sqlType());
		}
		else {
			try {
				st.setString(index, encrypt(value));
			}
			catch (final GeneralSecurityException e) {
				throw new UserTypeConfigurationException("Error encrypting object.", e);
			}
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see org.hibernate.usertype.UserType#replace(java.lang.Object, java.lang.Object,
	 *      java.lang.Object)
	 */
	public Object replace(final Object original, final Object target, final Object owner) throws HibernateException {
		return original;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see org.hibernate.usertype.UserType#sqlTypes()
	 */
	public int[] sqlTypes() {
		return sqlTypes;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see org.hibernate.usertype.ParameterizedType#setParameterValues(java.util.Properties)
	 */
	public synchronized void setParameterValues(final Properties parameters) {
		encryptor = getEncryptor(parameters);
	}

	private Encryptor getEncryptor(final Properties parameters) {
		Encryptor encryptor;

		// get encryptor from store if encryptor name is set
		final String property = parameters.getProperty(KEY_ENCRYPTOR_NAME);
		if (property != null) {
			encryptor = EncryptorStore.get(property);
			if (encryptor == null) {
				throw new UserTypeConfigurationException("Could not find encryptor in store with name: "
						+ property);
			}
			return encryptor;
		}

		// prepare encryptor using mapping file parameters
		encryptor = new Encryptor(Base64Encoder.getInstance());
		return encryptor.setAlgorithmParameters(loadAlgorithmParameters(parameters));
	}

	private AlgorithmParameters<?> loadAlgorithmParameters(final Properties parameters) {
		AlgorithmParameters<?> algorithmParameters = null;
		String property;

		// instantiate algorithmParameters
		property = parameters.getProperty(KEY_PARAM_CLASS);
		if (property == null) {
			throw new UserTypeConfigurationException("Missing '" + KEY_PARAM_CLASS
					+ "' property in Hibernate mapping.");
		}
		try {
			algorithmParameters = (AlgorithmParameters<?>) Class.forName(property).newInstance();
		}
		catch (final Exception e) {
			throw new UserTypeConfigurationException("Error instantiating: " + property, e);
		}

		// instantiate text encoder if necessary
		property = parameters.getProperty(KEY_PARAM_ENCODER_CLASS);
		if (property != null) {
			try {
				final Class<?> encoderClass = Class.forName(property);
				final TextEncoder encoder = (TextEncoder) encoderClass.getMethod("getInstance").invoke(null);
				ReflectionUtil.setFieldValue(algorithmParameters, encoder, FIELD_TEXT_ENCODER);
			}
			catch (final Exception e) {
				throw new UserTypeConfigurationException("Error instantiating: " + property, e);
			}
		}

		// set key
		property = parameters.getProperty(KEY_ENCRYPTION_KEY);
		if (property == null) {
			throw new UserTypeConfigurationException("Missing '" + KEY_ENCRYPTION_KEY
					+ "' property in Hibernate mapping.");
		}
		algorithmParameters.setKey(property);

		// set algorithm
		property = parameters.getProperty(KEY_ALGORITHM);
		if (property != null) {
			try {
				ReflectionUtil.setFieldValue(algorithmParameters, property, FIELD_ALGORITHM);
			}
			catch (final Exception e) {
				throw new UserTypeConfigurationException("Error setting '" + FIELD_ALGORITHM + "' on "
						+ algorithmParameters.getClass().getSimpleName(), e);
			}
		}

		// set providerName
		property = parameters.getProperty(KEY_PROVIDER_NAME);
		if (property != null) {
			algorithmParameters.setProviderName(property);
		}

		// set provider
		property = parameters.getProperty(KEY_PROVIDER_CLASS);
		if (property != null) {
			try {
				algorithmParameters.setProvider((Provider) Class.forName(property).newInstance());
			}
			catch (final Exception e) {
				throw new UserTypeConfigurationException("Error instantiating: " + property, e);
			}
		}

		// set mac key
		property = parameters.getProperty(KEY_MAC_KEY);
		if (property != null) {
			algorithmParameters.setMacKey(property);
		}

		// set mac algorithm
		property = parameters.getProperty(KEY_MAC_ALGORITHM);
		if (property != null) {
			algorithmParameters.setMacAlgorithm(property);
		}

		// if not a block cipher, return
		if (!(algorithmParameters instanceof AbstractBlockCipherParameters)) {
			return algorithmParameters;
		}
		final AbstractBlockCipherParameters<?> blockCipherParameters = (AbstractBlockCipherParameters<?>) algorithmParameters;

		// set block mode
		property = parameters.getProperty(KEY_BLOCK_MODE);
		if (property != null) {
			blockCipherParameters.setBlockMode(property);
		}

		// set block size
		property = parameters.getProperty(KEY_BLOCK_SIZE);
		if (property != null) {
			blockCipherParameters.setBlockSize(Integer.valueOf(property));
		}

		// set block padding
		property = parameters.getProperty(KEY_PADDING);
		if (property != null) {
			blockCipherParameters.setPadding(property);
		}

		// if not a PBE cipher, return
		if (!(algorithmParameters instanceof PbeParameters)) {
			return algorithmParameters;
		}
		final PbeParameters pbeParameters = (PbeParameters) algorithmParameters;

		// set salt size
		property = parameters.getProperty(KEY_SALT_SIZE);
		if (property != null) {
			pbeParameters.setSaltSize(Integer.valueOf(property));
		}

		// set iteration count
		property = parameters.getProperty(KEY_ITERATION_COUNT);
		if (property != null) {
			pbeParameters.setIterationCount(Integer.valueOf(property));
		}

		return algorithmParameters;
	}

	private void initializeIfNot() {
		try {
			encryptor.initialize();
		}
		catch (final GeneralSecurityException e) {
			throw new UserTypeConfigurationException("Error initializing cipher for Hibernate Usertype.", e);
		}
	}

	/**
	 * Returns the encryptor value.
	 *
	 * @return Returns the encryptor.
	 */
	protected ValueEncryptorInterface<Encryptor> getEncryptor() {
		return encryptor;
	}

}
