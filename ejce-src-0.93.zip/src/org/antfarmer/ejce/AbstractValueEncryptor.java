/*
 * Copyright 2006-2007 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.antfarmer.ejce;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.GeneralSecurityException;

import org.antfarmer.ejce.encoder.HexEncoder;
import org.antfarmer.ejce.encoder.TextEncoder;


/**
 * Abstract class for encrypting/decrypting text and other values.
 * 
 * @author Ameer Antar
 * @version 1.1
 * @param <T> the concrete type of this encryptor object.
 */
public abstract class AbstractValueEncryptor<T extends AbstractValueEncryptor<T>>
		extends AbstractEncryptor<T> implements ValueEncryptorInterface<T> {

	private static final long BYTE_BIT_MASK = 0xFF;
	
	private TextEncoder textEncoder;

	/**
	 * Initializes the AbstractValueEncryptor with a {@link HexEncoder} used for encoding/decoding byte
	 * arrays.
	 */
	public AbstractValueEncryptor() {
		this.textEncoder = HexEncoder.getInstance();
	}

	/**
	 * Initializes the AbstractValueEncryptor with the given {@link TextEncoder} used for
	 * encoding/decoding byte arrays.
	 * 
	 * @param textEncoder the {@link TextEncoder} used for encoding/decoding byte arrays
	 */
	public AbstractValueEncryptor(TextEncoder textEncoder) {
		this.textEncoder = textEncoder;
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#encrypt(java.lang.String)
	 */
	public String encrypt(String text) throws GeneralSecurityException {
		if (text == null) {
			return null;
		}
		return textEncoder.encode(encrypt(text.getBytes()));
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#decrypt(java.lang.String)
	 */
	public String decrypt(String text) throws GeneralSecurityException {
		if (text == null) {
			return null;
		}
		return new String(decrypt(textEncoder.decode(text)));
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#encryptCharacter(java.lang.Character)
	 */
	public String encryptCharacter(Character number)
			throws GeneralSecurityException {
		if (number == null) {
			return null;
		}
		return textEncoder.encode(encrypt(String.valueOf(number).getBytes()));
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#decryptCharacter(java.lang.String)
	 */
	public Character decryptCharacter(String text)
			throws GeneralSecurityException {
		if (text == null) {
			return null;
		}
		return new String(decrypt(textEncoder.decode(text))).charAt(0);
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#encryptLong(java.lang.Long)
	 */
	public String encryptLong(Long number) throws GeneralSecurityException {
		if (number == null) {
			return null;
		}
		byte[] bytes = new byte[Long.SIZE / Byte.SIZE];
		int b = 0;
		for (int i=bytes.length-1; i>=0; i--) {
			bytes[b++] = (byte) ((number >> (i * Byte.SIZE)) & BYTE_BIT_MASK);
		}
		return textEncoder.encode(encrypt(bytes));
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#decryptLong(java.lang.String)
	 */
	public Long decryptLong(String text) throws GeneralSecurityException {
		if (text == null) {
			return null;
		}
		byte[] bytes = decrypt(textEncoder.decode(text));
		Long num = 0L;
		int b = 0;
		for (int i=bytes.length-1; i>=0; i--) {
			long n = bytes[b++];
			num |= ((n << (i * Byte.SIZE)) & ((long)(BYTE_BIT_MASK << (i * Byte.SIZE))));
		}
		return num;
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#encryptInteger(java.lang.Integer)
	 */
	public String encryptInteger(Integer number)
			throws GeneralSecurityException {
		if (number == null) {
			return null;
		}
		byte[] bytes = new byte[Integer.SIZE / Byte.SIZE];
		int b = 0;
		for (int i=bytes.length-1; i>=0; i--) {
			bytes[b++] = (byte) ((number >> (i * Byte.SIZE)) & BYTE_BIT_MASK);
		}
		return textEncoder.encode(encrypt(bytes));
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#decryptInteger(java.lang.String)
	 */
	public Integer decryptInteger(String text) throws GeneralSecurityException {
		if (text == null) {
			return null;
		}
		byte[] bytes = decrypt(textEncoder.decode(text));
		Integer num = 0;
		int b = 0;
		for (int i=bytes.length-1; i>=0; i--) {
			int n = bytes[b++];
			num |= ((n << (i * Byte.SIZE)) & ((int)(BYTE_BIT_MASK << (i * Byte.SIZE))));
		}
		return num;
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#encryptShort(java.lang.Short)
	 */
	public String encryptShort(Short number) throws GeneralSecurityException {
		if (number == null) {
			return null;
		}
		byte[] bytes = new byte[Short.SIZE / Byte.SIZE];
		int b = 0;
		for (int i=bytes.length-1; i>=0; i--) {
			bytes[b++] = (byte) ((number >> (i * Byte.SIZE)) & BYTE_BIT_MASK);
		}
		return textEncoder.encode(encrypt(bytes));
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#decryptShort(java.lang.String)
	 */
	public Short decryptShort(String text) throws GeneralSecurityException {
		if (text == null) {
			return null;
		}
		byte[] bytes = decrypt(textEncoder.decode(text));
		Short num = 0;
		int b = 0;
		for (int i=bytes.length-1; i>=0; i--) {
			short n = bytes[b++];
			num |= ((n << (i * Byte.SIZE)) & ((short)(BYTE_BIT_MASK << (i * Byte.SIZE))));
		}
		return num;
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#encryptBoolean(java.lang.Boolean)
	 */
	public String encryptBoolean(Boolean value)
			throws GeneralSecurityException {
		if (value == null) {
			return null;
		}
		return textEncoder.encode(encrypt(new byte[] {(byte) (value ? 1 : 0)}));
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#decryptBoolean(java.lang.String)
	 */
	public Boolean decryptBoolean(String text) throws GeneralSecurityException {
		if (text == null) {
			return null;
		}
		return decrypt(textEncoder.decode(text))[0] == 1 ? true : false;
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#encryptDouble(java.lang.Double)
	 */
	public String encryptDouble(Double number) throws GeneralSecurityException {
		if (number == null) {
			return null;
		}
		long n = Double.doubleToRawLongBits(number);
		byte[] bytes = new byte[Long.SIZE / Byte.SIZE];
		int b = 0;
		for (int i=bytes.length-1; i>=0; i--) {
			bytes[b++] = (byte) ((n >> (i * Byte.SIZE)) & BYTE_BIT_MASK);
		}
		return textEncoder.encode(encrypt(bytes));
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#decryptDouble(java.lang.String)
	 */
	public Double decryptDouble(String text) throws GeneralSecurityException {
		if (text == null) {
			return null;
		}
		byte[] bytes = decrypt(textEncoder.decode(text));
		Long num = 0L;
		int b = 0;
		for (int i=bytes.length-1; i>=0; i--) {
			long n = bytes[b++];
			num |= ((n << (i * Byte.SIZE)) & ((long)(BYTE_BIT_MASK << (i * Byte.SIZE))));
		}
		return Double.longBitsToDouble(num);
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#encryptFloat(java.lang.Float)
	 */
	public String encryptFloat(Float number) throws GeneralSecurityException {
		if (number == null) {
			return null;
		}
		int n = Float.floatToRawIntBits(number);
		byte[] bytes = new byte[Integer.SIZE / Byte.SIZE];
		int b = 0;
		for (int i=bytes.length-1; i>=0; i--) {
			bytes[b++] = (byte) ((n >> (i * Byte.SIZE)) & BYTE_BIT_MASK);
		}
		return textEncoder.encode(encrypt(bytes));
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#decryptFloat(java.lang.String)
	 */
	public Float decryptFloat(String text) throws GeneralSecurityException {
		if (text == null) {
			return null;
		}
		byte[] bytes = decrypt(textEncoder.decode(text));
		Integer intBits = 0;
		int b = 0;
		for (int i=bytes.length-1; i>=0; i--) {
			int n = bytes[b++];
			intBits |= ((n << (i * Byte.SIZE)) & ((int)(BYTE_BIT_MASK << (i * Byte.SIZE))));
		}
		return Float.intBitsToFloat(intBits);
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#encryptObject(java.lang.Object)
	 */
	public String encryptObject(Object object)
			throws GeneralSecurityException, IOException {
		if (object == null) {
			return null;
		}
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ObjectOutputStream oos = null;
		try {
			oos = new ObjectOutputStream(baos);
			oos.writeObject(object);
		}
		catch (IOException e) {
			throw e;
		}
		finally {
			if (oos != null) {
				oos.close();
			}
		}
		return textEncoder.encode(encrypt(baos.toByteArray()));
	}

	/**
	 * {@inheritDoc} 
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#decryptObject(java.lang.String)
	 */
	public Object decryptObject(String text)
			throws GeneralSecurityException, IOException, ClassNotFoundException {
		if (text == null) {
			return null;
		}
		Object object;
		ByteArrayInputStream bais = new ByteArrayInputStream(decrypt(textEncoder.decode(text)));
		ObjectInputStream ois = null;
		try {
			ois = new ObjectInputStream(bais);
			object = ois.readObject();
		}
		catch (IOException e) {
			throw e;
		}
		finally {
			if (ois != null) {
				ois.close();
			}
		}
		return object;
	}

}
