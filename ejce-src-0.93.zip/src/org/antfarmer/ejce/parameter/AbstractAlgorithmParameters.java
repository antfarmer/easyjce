/*
 * Copyright 2006-2007 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.antfarmer.ejce.parameter;

import java.security.GeneralSecurityException;
import java.security.Key;
import java.security.Provider;
import java.security.SecureRandom;
import java.security.spec.AlgorithmParameterSpec;

import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.antfarmer.ejce.encoder.TextEncoder;
import org.antfarmer.ejce.util.CryptoUtil;


/**
 * Abstract AlgorithmParameters class.
 * 
 * @author Ameer Antar
 * @version 1.1
 * @param <T> the concrete type of this object.
 */
public abstract class AbstractAlgorithmParameters<T extends AbstractAlgorithmParameters<T>>
		implements AlgorithmParameters<T> {

	/**
	 * 128-bit key size.
	 */
	public static final int KEY_SIZE_128 = 128;

	/**
	 * 192-bit key size (not available in all jurisdictions).
	 */
	public static final int KEY_SIZE_192 = 192;

	/**
	 * 256-bit key size (not available in all jurisdictions).
	 */
	public static final int KEY_SIZE_256 = 256;

	/**
	 * 128-bit MAC key size (Suggested minimum key size for HmacMD5).
	 */
	public static final int MAC_KEY_SIZE_128 = 128;

	/**
	 * 160-bit MAC key size (Suggested minimum key size for HmacSHA1).
	 */
	public static final int MAC_KEY_SIZE_160 = 160;

	/**
	 * The HMAC-MD5 keyed-hashing algorithm as defined in RFC 2104: "HMAC: Keyed-Hashing for Message
	 * Authentication" (February 1997).
	 */
	public static final String MAC_ALGORITHM_HMAC_MD5 = "HmacMD5";

	/**
	 * The HMAC-SHA1 keyed-hashing algorithm as defined in RFC 2104: "HMAC: Keyed-Hashing for
	 * Message Authentication" (February 1997).
	 */
	public static final String MAC_ALGORITHM_HMAC_SHA1 = "HmacSHA1";

	private TextEncoder textEncoder;

	private byte[] rawKey;

	private Key key;

	private String algorithm = getDefaultAlgorithm();
	
	private String providerName;
	
	private Provider provider;

	private int keySize = getDefaultKeySize();
	
	private byte[] rawMacKey;

	private Key macKey;

	private int macKeySize;
	
	private String macAlgorithm;

	/**
	 * Initializes the AbstractAlgorithmParameters.
	 */
	protected AbstractAlgorithmParameters() {
		// do nothing
	}

	/**
	 * Initializes the AbstractAlgorithmParameters with a {@link TextEncoder}.
	 * @param textEncoder
	 */
	protected AbstractAlgorithmParameters(TextEncoder textEncoder) {
		this.textEncoder = textEncoder;
	}
	
	/**
	 * Returns the defaultAlgorithm.
	 * @return the defaultAlgorithm
	 */
	protected abstract String getDefaultAlgorithm();
	
	/**
	 * Returns the defaultKeySize.
	 * @return the defaultKeySize
	 */
	protected int getDefaultKeySize() {
		return KEY_SIZE_128;
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.parameter.AlgorithmParameters#getKey()
	 */
	public Key getKey() throws GeneralSecurityException {
		if (key != null) {
			return key;
		}
		if (rawKey == null) {
			rawKey = CryptoUtil.generateSecretKey(keySize, algorithm, getProviderName(), getProvider()).getEncoded();
		}
		key = CryptoUtil.getSecretKeyFromRawKey(rawKey, algorithm);
		return key;
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.parameter.AlgorithmParameters#getKeySize()
	 */
	public int getKeySize() {
		return keySize;
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.parameter.AlgorithmParameters#setKeySize(int)
	 */
	@SuppressWarnings("unchecked")
	public T setKeySize(int keySize) {
		this.keySize = keySize;
		return (T) this;
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.parameter.AlgorithmParameters#setKey(byte[])
	 */
	@SuppressWarnings("unchecked")
	public T setKey(byte[] key) {
		this.rawKey = key;
		return (T) this;
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.parameter.AlgorithmParameters#setKey(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public T setKey(String key) {
		if (getTextEncoder() == null) {
			this.rawKey = key.getBytes();
			return (T) this;
		}
		this.rawKey = getTextEncoder().decode(key);
		return (T) this;
	}
	
	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.parameter.AlgorithmParameters#getAlgorithm()
	 */
	public String getAlgorithm() {
		return algorithm;
	}

	/**
	 * Sets the algorithm value.
	 * 
	 * @param algorithm The algorithm to set.
	 * @return this concrete class
	 */
	@SuppressWarnings("unchecked")
	protected T setAlgorithm(String algorithm) {
		this.algorithm = algorithm;
		return (T) this;
	}
	
	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.parameter.AlgorithmParameters#generateParameterSpecData()
	 */
	public byte[] generateParameterSpecData() {
		int paramSize = getParameterSpecSize();
		if (paramSize > 0) {
			byte[] parameterData = new byte[paramSize];
			new SecureRandom().nextBytes(parameterData);
			return parameterData;
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.parameter.AlgorithmParameters#generateParameterSpec(byte[])
	 */
	public AlgorithmParameterSpec generateParameterSpec(byte[] parameterData) {
		if (parameterData == null) {
			return null;
		}
		return new IvParameterSpec(parameterData);
	}

	/**
	 * Returns the {@link TextEncoder}.
	 * @return Returns the {@link TextEncoder}.
	 */
	protected TextEncoder getTextEncoder() {
		return textEncoder;
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.parameter.AlgorithmParameters#getKeySize()
	 */
	public int getMacKeySize() {
		return macKeySize;
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.parameter.AlgorithmParameters#setKeySize(int)
	 */
	@SuppressWarnings("unchecked")
	public T setMacKeySize(int macKeySize) {
		this.macKeySize = macKeySize;
		return (T) this;
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.parameter.AlgorithmParameters#getMacKey()
	 */
	public Key getMacKey() throws GeneralSecurityException {
		if (macKey != null) {
			return macKey;
		}
		if (rawMacKey == null) {
			if (macKeySize < 1) {
				return null;
			}
			rawMacKey = CryptoUtil.generateSecretKey(macKeySize, macAlgorithm, getProviderName(), getProvider()).getEncoded();
		}
		macKey = new SecretKeySpec(rawMacKey, macAlgorithm);
		return macKey;
	}
	
	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.parameter.AlgorithmParameters#setMacKey(byte[])
	 */
	@SuppressWarnings("unchecked")
	public T setMacKey(byte[] macKey) {
		this.rawMacKey = macKey;
		return (T) this;
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.parameter.AlgorithmParameters#setMacKey(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public T setMacKey(String macKey) {
		if (textEncoder == null) {
			this.rawMacKey = macKey.getBytes();
			return (T) this;
		}
		this.rawMacKey = textEncoder.decode(macKey);
		return (T) this;
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.parameter.AlgorithmParameters#getMacAlgorithm()
	 */
	public String getMacAlgorithm() {
		return macAlgorithm;
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.parameter.AlgorithmParameters#setMacAlgorithm(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public T setMacAlgorithm(String macAlgorithm) {
		this.macAlgorithm = macAlgorithm;
		return (T) this;
	}
		
	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.parameter.AlgorithmParameters#getProviderName()
	 */
	public String getProviderName() {
		return providerName;
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.parameter.AlgorithmParameters#setProviderName(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public T setProviderName(String providerName) {
		this.providerName = providerName;
		return (T) this;
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.parameter.AlgorithmParameters#getProvider()
	 */
	public Provider getProvider() {
		return provider;
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.parameter.AlgorithmParameters#setProvider(java.security.Provider)
	 */
	@SuppressWarnings("unchecked")
	public T setProvider(Provider provider) {
		this.provider = provider;
		return (T) this;
	}
	
}
