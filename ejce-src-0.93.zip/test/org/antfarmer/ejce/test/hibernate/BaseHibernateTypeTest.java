/*
 * Copyright 2006-2007 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.antfarmer.ejce.test.hibernate;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;

import java.security.GeneralSecurityException;
import java.util.Properties;

import org.antfarmer.ejce.Encryptor;
import org.antfarmer.ejce.EncryptorStore;
import org.antfarmer.ejce.encoder.Base32Encoder;
import org.antfarmer.ejce.hibernate.AbstractHibernateType;
import org.antfarmer.ejce.parameter.BlowfishParameters;
import org.antfarmer.ejce.parameter.DesEdeParameters;
import org.antfarmer.ejce.parameter.PbeParameters;
import org.antfarmer.ejce.util.ReflectionUtil;
import org.junit.Test;

/**
 *
 * @author Ameer Antar
 * @version 1.0
 */
public class BaseHibernateTypeTest extends AbstractHibernateType {

	private static final String KEY_ENCRYPTOR_NAME = "encryptor";

	private static final String KEY_PARAM_CLASS = "paramClass";

	private static final String KEY_PARAM_ENCODER_CLASS = "paramEncoder";

	private static final String KEY_ENCRYPTION_KEY = "key";

	private static final String KEY_ALGORITHM = "algorithm";

	private static final String KEY_PROVIDER_NAME = "providerName";

	private static final String KEY_PROVIDER_CLASS = "providerClass";

	private static final String KEY_MAC_KEY = "macKey";

	private static final String KEY_MAC_ALGORITHM = "macAlgorithm";

	private static final String KEY_BLOCK_MODE = "blockMode";

	private static final String KEY_BLOCK_SIZE = "blockSize";

	private static final String KEY_PADDING = "padding";

	private static final String KEY_SALT_SIZE = "saltSize";

	private static final String KEY_ITERATION_COUNT = "iterations";

	/**
	 *
	 */
	@Test
	public void testSetStoredEncryptor() {
		final DesEdeParameters parameters = new DesEdeParameters();
		parameters.setKeySize(DesEdeParameters.KEY_SIZE_DES_EDE_112)
				.setBlockMode(DesEdeParameters.BLOCK_MODE_CFB)
				.setPadding(DesEdeParameters.PADDING_PKCS5)
				.setMacAlgorithm(DesEdeParameters.MAC_ALGORITHM_HMAC_MD5)
				.setMacKeySize(DesEdeParameters.MAC_KEY_SIZE_128);
		final Encryptor encryptor = new Encryptor().setAlgorithmParameters(parameters);
		EncryptorStore.add("name", encryptor);

		final Properties properties = new Properties();
		properties.put(KEY_ENCRYPTOR_NAME, "name");
		setParameterValues(properties);

		assertSame(encryptor, getEncryptor());
	}

	/**
	 * @throws Exception
	 */
	@Test
	public void testSetParameterValues() throws Exception {
		final String key = Base32Encoder.getInstance().encode("SMOKESOMEOFMYTIE".getBytes());
		final String macKey = Base32Encoder.getInstance().encode("SMOKEAJAYINTHEGOODOLUSA".getBytes());
		final String saltSize = "6";
		final String iterations = "700";
		final Properties properties = new Properties();
		properties.put(KEY_PARAM_CLASS, PbeParameters.class.getName());
		properties.put(KEY_PARAM_ENCODER_CLASS, Base32Encoder.class.getName());
		properties.put(KEY_ENCRYPTION_KEY, key);
		properties.put(KEY_ALGORITHM, PbeParameters.ALGORITHM_PBE_MD5_DES);
		properties.put(KEY_PROVIDER_CLASS, sun.security.provider.Sun.class.getName());
		properties.put(KEY_MAC_ALGORITHM, PbeParameters.MAC_ALGORITHM_HMAC_MD5);
		properties.put(KEY_MAC_KEY, macKey);
		properties.put(KEY_BLOCK_MODE, PbeParameters.BLOCK_MODE_OFB);
		properties.put(KEY_PADDING, PbeParameters.PADDING_PKCS5);
		properties.put(KEY_SALT_SIZE, saltSize);
		properties.put(KEY_ITERATION_COUNT, iterations);

		setParameterValues(properties);
		final Encryptor encryptor = (Encryptor) getEncryptor();
		final PbeParameters parameters = (PbeParameters) ReflectionUtil.getFieldValue(encryptor, "parameters");

		assertEquals(Base32Encoder.class, ReflectionUtil.getFieldValue(parameters, "textEncoder").getClass());
		assertEquals(key, Base32Encoder.getInstance().encode(parameters.getKey().getEncoded()));
		assertEquals(PbeParameters.ALGORITHM_PBE_MD5_DES, parameters.getAlgorithm());
		assertEquals(sun.security.provider.Sun.class, parameters.getProvider().getClass());
		assertEquals(PbeParameters.MAC_ALGORITHM_HMAC_MD5, parameters.getMacAlgorithm());
		assertEquals(macKey, Base32Encoder.getInstance().encode(parameters.getMacKey().getEncoded()));
		assertEquals(PbeParameters.BLOCK_MODE_OFB, parameters.getBlockMode());
		assertEquals(PbeParameters.PADDING_PKCS5, parameters.getPadding());
		assertEquals(Integer.valueOf(saltSize), (Integer)parameters.getSaltSize());
		assertEquals(Integer.valueOf(iterations), (Integer)parameters.getIterationCount());
	}

	/**
	 * @throws Exception
	 */
	@Test
	public void testSetParameterValues2() throws Exception {

		final String key = Base32Encoder.getInstance().encode("BINGBINGA".getBytes());
		final String macKey = Base32Encoder.getInstance().encode("BEEOWANOWEEWEE".getBytes());
		final String providerName = "SunJCE";
		final String blockSize = "16";
		final Properties properties = new Properties();
		properties.put(KEY_PARAM_CLASS, BlowfishParameters.class.getName());
		properties.put(KEY_PARAM_ENCODER_CLASS, Base32Encoder.class.getName());
		properties.put(KEY_ENCRYPTION_KEY, key);
		properties.put(KEY_PROVIDER_NAME, providerName);
		properties.put(KEY_MAC_ALGORITHM, BlowfishParameters.MAC_ALGORITHM_HMAC_SHA1);
		properties.put(KEY_MAC_KEY, macKey);
		properties.put(KEY_BLOCK_MODE, BlowfishParameters.BLOCK_MODE_OFB);
		properties.put(KEY_BLOCK_SIZE, blockSize);
		properties.put(KEY_PADDING, BlowfishParameters.PADDING_NONE);

		setParameterValues(properties);
		final Encryptor encryptor = (Encryptor) getEncryptor();
		final BlowfishParameters parameters = (BlowfishParameters) ReflectionUtil.getFieldValue(encryptor, "parameters");

		assertEquals(Base32Encoder.class, ReflectionUtil.getFieldValue(parameters, "textEncoder").getClass());
		assertEquals(key, Base32Encoder.getInstance().encode(parameters.getKey().getEncoded()));
		assertEquals(providerName, parameters.getProviderName());
		assertEquals(BlowfishParameters.MAC_ALGORITHM_HMAC_SHA1, parameters.getMacAlgorithm());
		assertEquals(macKey, Base32Encoder.getInstance().encode(parameters.getMacKey().getEncoded()));
		assertEquals(BlowfishParameters.BLOCK_MODE_OFB, parameters.getBlockMode());
		assertEquals(Integer.valueOf(blockSize), (Integer)parameters.getBlockSize());
		assertEquals(BlowfishParameters.PADDING_NONE, parameters.getPadding());
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.hibernate.AbstractHibernateType#decrypt(java.lang.String)
	 */
	@Override
	protected Object decrypt(final String value) throws GeneralSecurityException {
		return null;
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.hibernate.AbstractHibernateType#encrypt(java.lang.Object)
	 */
	@Override
	protected String encrypt(final Object value) throws GeneralSecurityException {
		return null;
	}

	/**
	 * {@inheritDoc}
	 * @see org.hibernate.usertype.UserType#returnedClass()
	 */
	public Class<?> returnedClass() {
		return null;
	}

}
