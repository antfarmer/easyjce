package org.hibernate.secure;

/**
 * Package defining support for declarative security of CRUD operations via JACC.
 */
