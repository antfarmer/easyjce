package org.bouncycastle.bcpg;

/**
 */
public class Packet
    implements PacketTags
{

}
