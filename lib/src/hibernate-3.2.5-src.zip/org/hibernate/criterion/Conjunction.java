package org.hibernate.criterion;


/**
 * @author Gavin King
 */
public class Conjunction extends Junction {

	public Conjunction() {
		super("and");
	}

}
