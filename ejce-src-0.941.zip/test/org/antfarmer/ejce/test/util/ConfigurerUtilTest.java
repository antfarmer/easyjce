/*
 * Copyright 2006-2007 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.antfarmer.ejce.test.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;

import java.util.Properties;

import org.antfarmer.ejce.Encryptor;
import org.antfarmer.ejce.EncryptorStore;
import org.antfarmer.ejce.encoder.Base32Encoder;
import org.antfarmer.ejce.encoder.Base64UrlEncoder;
import org.antfarmer.ejce.encoder.HexEncoder;
import org.antfarmer.ejce.parameter.BlowfishParameters;
import org.antfarmer.ejce.parameter.DesEdeParameters;
import org.antfarmer.ejce.parameter.PbeParameters;
import org.antfarmer.ejce.util.ConfigurerUtil;
import org.antfarmer.ejce.util.ReflectionUtil;
import org.junit.Test;

/**
 *
 * @author Ameer Antar
 * @version 1.0
 */
public class ConfigurerUtilTest {

	/**
	 *
	 */
	@Test
	public void testSetStoredEncryptor() {
		final DesEdeParameters parameters = new DesEdeParameters();
		parameters.setKeySize(DesEdeParameters.KEY_SIZE_DES_EDE_112)
				.setBlockMode(DesEdeParameters.BLOCK_MODE_CFB)
				.setPadding(DesEdeParameters.PADDING_PKCS5)
				.setMacAlgorithm(DesEdeParameters.MAC_ALGORITHM_HMAC_MD5)
				.setMacKeySize(DesEdeParameters.MAC_KEY_SIZE_128);
		final Encryptor encryptor = new Encryptor().setAlgorithmParameters(parameters);
		EncryptorStore.add("name", encryptor);

		final Properties properties = new Properties();
		properties.put(ConfigurerUtil.KEY_ENCRYPTOR_STORE_KEY, "name");

		assertSame(encryptor, ConfigurerUtil.configureEncryptor(properties));
	}

	/**
	 * @throws Exception
	 */
	@Test
	public void testSetParameterValues() throws Exception {
		final String key = Base32Encoder.getInstance().encode("SMOKESOMEOFMYTIE".getBytes());
		final String macKey = Base32Encoder.getInstance().encode("SMOKEAJAYINTHEGOODOLUSA".getBytes());
		final String saltSize = "6";
		final String iterations = "700";
		final Properties properties = new Properties();
		properties.put(ConfigurerUtil.KEY_ENCODER_CLASS, HexEncoder.class.getName());
		properties.put(ConfigurerUtil.KEY_PARAM_CLASS, PbeParameters.class.getName());
		properties.put(ConfigurerUtil.KEY_PARAM_ENCODER_CLASS, Base32Encoder.class.getName());
		properties.put(ConfigurerUtil.KEY_ENCRYPTION_KEY, key);
		properties.put(ConfigurerUtil.KEY_ALGORITHM, PbeParameters.ALGORITHM_PBE_MD5_DES);
		properties.put(ConfigurerUtil.KEY_PROVIDER_CLASS, sun.security.provider.Sun.class.getName());
		properties.put(ConfigurerUtil.KEY_MAC_ALGORITHM, PbeParameters.MAC_ALGORITHM_HMAC_MD5);
		properties.put(ConfigurerUtil.KEY_MAC_KEY, macKey);
		properties.put(ConfigurerUtil.KEY_BLOCK_MODE, PbeParameters.BLOCK_MODE_OFB);
		properties.put(ConfigurerUtil.KEY_PADDING, PbeParameters.PADDING_PKCS5);
		properties.put(ConfigurerUtil.KEY_SALT_SIZE, saltSize);
		properties.put(ConfigurerUtil.KEY_ITERATION_COUNT, iterations);

		final Encryptor encryptor = ConfigurerUtil.configureEncryptor(properties);
		final PbeParameters parameters = (PbeParameters) ReflectionUtil.getFieldValue(encryptor, "parameters");

		assertEquals(HexEncoder.class, ReflectionUtil.getFieldValue(encryptor, "textEncoder").getClass());
		assertEquals(Base32Encoder.class, ReflectionUtil.getFieldValue(parameters, "textEncoder").getClass());
		assertEquals(key, Base32Encoder.getInstance().encode(parameters.getKey().getEncoded()));
		assertEquals(PbeParameters.ALGORITHM_PBE_MD5_DES, parameters.getAlgorithm());
		assertEquals(sun.security.provider.Sun.class, parameters.getProvider().getClass());
		assertEquals(PbeParameters.MAC_ALGORITHM_HMAC_MD5, parameters.getMacAlgorithm());
		assertEquals(macKey, Base32Encoder.getInstance().encode(parameters.getMacKey().getEncoded()));
		assertEquals(PbeParameters.BLOCK_MODE_OFB, parameters.getBlockMode());
		assertEquals(PbeParameters.PADDING_PKCS5, parameters.getPadding());
		assertEquals(Integer.valueOf(saltSize), (Integer)parameters.getSaltSize());
		assertEquals(Integer.valueOf(iterations), (Integer)parameters.getIterationCount());
	}

	/**
	 * @throws Exception
	 */
	@Test
	public void testSetParameterValues2() throws Exception {

		final String key = Base32Encoder.getInstance().encode("BINGBINGA".getBytes());
		final String macKey = Base32Encoder.getInstance().encode("BEEOWANOWEEWEE".getBytes());
		final String providerName = "SunJCE";
		final String blockSize = "16";
		final Properties properties = new Properties();
		properties.put(ConfigurerUtil.KEY_ENCODER_CLASS, Base64UrlEncoder.class.getName());
		properties.put(ConfigurerUtil.KEY_PARAM_CLASS, BlowfishParameters.class.getName());
		properties.put(ConfigurerUtil.KEY_PARAM_ENCODER_CLASS, Base32Encoder.class.getName());
		properties.put(ConfigurerUtil.KEY_ENCRYPTION_KEY, key);
		properties.put(ConfigurerUtil.KEY_PROVIDER_NAME, providerName);
		properties.put(ConfigurerUtil.KEY_MAC_ALGORITHM, BlowfishParameters.MAC_ALGORITHM_HMAC_SHA1);
		properties.put(ConfigurerUtil.KEY_MAC_KEY, macKey);
		properties.put(ConfigurerUtil.KEY_BLOCK_MODE, BlowfishParameters.BLOCK_MODE_OFB);
		properties.put(ConfigurerUtil.KEY_BLOCK_SIZE, blockSize);
		properties.put(ConfigurerUtil.KEY_PADDING, BlowfishParameters.PADDING_NONE);

		final Encryptor encryptor = ConfigurerUtil.configureEncryptor(properties);
		final BlowfishParameters parameters = (BlowfishParameters) ReflectionUtil.getFieldValue(encryptor, "parameters");

		assertEquals(Base64UrlEncoder.class, ReflectionUtil.getFieldValue(encryptor, "textEncoder").getClass());
		assertEquals(Base32Encoder.class, ReflectionUtil.getFieldValue(parameters, "textEncoder").getClass());
		assertEquals(key, Base32Encoder.getInstance().encode(parameters.getKey().getEncoded()));
		assertEquals(providerName, parameters.getProviderName());
		assertEquals(BlowfishParameters.MAC_ALGORITHM_HMAC_SHA1, parameters.getMacAlgorithm());
		assertEquals(macKey, Base32Encoder.getInstance().encode(parameters.getMacKey().getEncoded()));
		assertEquals(BlowfishParameters.BLOCK_MODE_OFB, parameters.getBlockMode());
		assertEquals(Integer.valueOf(blockSize), (Integer)parameters.getBlockSize());
		assertEquals(BlowfishParameters.PADDING_NONE, parameters.getPadding());
	}

	/**
	 *
	 */
	@Test
	public void testSetStoredEncryptorViaSysProps() {
		final DesEdeParameters parameters = new DesEdeParameters();
		parameters.setKeySize(DesEdeParameters.KEY_SIZE_DES_EDE_112)
				.setBlockMode(DesEdeParameters.BLOCK_MODE_CFB)
				.setPadding(DesEdeParameters.PADDING_PKCS5)
				.setMacAlgorithm(DesEdeParameters.MAC_ALGORITHM_HMAC_MD5)
				.setMacKeySize(DesEdeParameters.MAC_KEY_SIZE_128);
		final Encryptor encryptor = new Encryptor().setAlgorithmParameters(parameters);
		EncryptorStore.add("name", encryptor);

		final VolatileProperties properties = new VolatileProperties(System.getProperties());
		final String propPrefix = "ejce.encryptor1";
		properties.put(getPropertyName(propPrefix, ConfigurerUtil.KEY_ENCRYPTOR_STORE_KEY), "name");

		assertSame(encryptor, ConfigurerUtil.configureEncryptor(properties.getProperties(), propPrefix));

		properties.rollback();
	}

	/**
	 * @throws Exception
	 */
	@Test
	public void testSetParameterValuesViaSysProps() throws Exception {
		final String key = Base32Encoder.getInstance().encode("SMOKESOMEOFMYTIE".getBytes());
		final String macKey = Base32Encoder.getInstance().encode("SMOKEAJAYINTHEGOODOLUSA".getBytes());
		final String saltSize = "6";
		final String iterations = "700";
		final String propPrefix = "ejce.encryptor1";
		final VolatileProperties properties = new VolatileProperties(System.getProperties());
		properties.put(getPropertyName(propPrefix, ConfigurerUtil.KEY_ENCODER_CLASS), HexEncoder.class.getName());
		properties.put(getPropertyName(propPrefix, ConfigurerUtil.KEY_PARAM_CLASS), PbeParameters.class.getName());
		properties.put(getPropertyName(propPrefix, ConfigurerUtil.KEY_PARAM_ENCODER_CLASS), Base32Encoder.class.getName());
		properties.put(getPropertyName(propPrefix, ConfigurerUtil.KEY_ENCRYPTION_KEY), key);
		properties.put(getPropertyName(propPrefix, ConfigurerUtil.KEY_ALGORITHM), PbeParameters.ALGORITHM_PBE_MD5_DES);
		properties.put(getPropertyName(propPrefix, ConfigurerUtil.KEY_PROVIDER_CLASS), sun.security.provider.Sun.class.getName());
		properties.put(getPropertyName(propPrefix, ConfigurerUtil.KEY_MAC_ALGORITHM), PbeParameters.MAC_ALGORITHM_HMAC_MD5);
		properties.put(getPropertyName(propPrefix, ConfigurerUtil.KEY_MAC_KEY), macKey);
		properties.put(getPropertyName(propPrefix, ConfigurerUtil.KEY_BLOCK_MODE), PbeParameters.BLOCK_MODE_OFB);
		properties.put(getPropertyName(propPrefix, ConfigurerUtil.KEY_PADDING), PbeParameters.PADDING_PKCS5);
		properties.put(getPropertyName(propPrefix, ConfigurerUtil.KEY_SALT_SIZE), saltSize);
		properties.put(getPropertyName(propPrefix, ConfigurerUtil.KEY_ITERATION_COUNT), iterations);

		final Encryptor encryptor = ConfigurerUtil.configureEncryptor(properties.getProperties(), propPrefix);
		final PbeParameters parameters = (PbeParameters) ReflectionUtil.getFieldValue(encryptor, "parameters");

		assertEquals(HexEncoder.class, ReflectionUtil.getFieldValue(encryptor, "textEncoder").getClass());
		assertEquals(Base32Encoder.class, ReflectionUtil.getFieldValue(parameters, "textEncoder").getClass());
		assertEquals(key, Base32Encoder.getInstance().encode(parameters.getKey().getEncoded()));
		assertEquals(PbeParameters.ALGORITHM_PBE_MD5_DES, parameters.getAlgorithm());
		assertEquals(sun.security.provider.Sun.class, parameters.getProvider().getClass());
		assertEquals(PbeParameters.MAC_ALGORITHM_HMAC_MD5, parameters.getMacAlgorithm());
		assertEquals(macKey, Base32Encoder.getInstance().encode(parameters.getMacKey().getEncoded()));
		assertEquals(PbeParameters.BLOCK_MODE_OFB, parameters.getBlockMode());
		assertEquals(PbeParameters.PADDING_PKCS5, parameters.getPadding());
		assertEquals(Integer.valueOf(saltSize), (Integer)parameters.getSaltSize());
		assertEquals(Integer.valueOf(iterations), (Integer)parameters.getIterationCount());

		properties.rollback();
	}

	/**
	 * @throws Exception
	 */
	@Test
	public void testSetParameterValues2ViaSysProps() throws Exception {

		final String key = Base32Encoder.getInstance().encode("BINGBINGA".getBytes());
		final String macKey = Base32Encoder.getInstance().encode("BEEOWANOWEEWEE".getBytes());
		final String providerName = "SunJCE";
		final String blockSize = "16";
		final String propPrefix = "ejce.encryptor1";
		final VolatileProperties properties = new VolatileProperties(System.getProperties());
		properties.put(getPropertyName(propPrefix, ConfigurerUtil.KEY_ENCODER_CLASS), Base64UrlEncoder.class.getName());
		properties.put(getPropertyName(propPrefix, ConfigurerUtil.KEY_PARAM_CLASS), BlowfishParameters.class.getName());
		properties.put(getPropertyName(propPrefix, ConfigurerUtil.KEY_PARAM_ENCODER_CLASS), Base32Encoder.class.getName());
		properties.put(getPropertyName(propPrefix, ConfigurerUtil.KEY_ENCRYPTION_KEY), key);
		properties.put(getPropertyName(propPrefix, ConfigurerUtil.KEY_PROVIDER_NAME), providerName);
		properties.put(getPropertyName(propPrefix, ConfigurerUtil.KEY_MAC_ALGORITHM), BlowfishParameters.MAC_ALGORITHM_HMAC_SHA1);
		properties.put(getPropertyName(propPrefix, ConfigurerUtil.KEY_MAC_KEY), macKey);
		properties.put(getPropertyName(propPrefix, ConfigurerUtil.KEY_BLOCK_MODE), BlowfishParameters.BLOCK_MODE_OFB);
		properties.put(getPropertyName(propPrefix, ConfigurerUtil.KEY_BLOCK_SIZE), blockSize);
		properties.put(getPropertyName(propPrefix, ConfigurerUtil.KEY_PADDING), BlowfishParameters.PADDING_NONE);

		final Encryptor encryptor = ConfigurerUtil.configureEncryptor(properties.getProperties(), propPrefix);
		final BlowfishParameters parameters = (BlowfishParameters) ReflectionUtil.getFieldValue(encryptor, "parameters");

		assertEquals(Base64UrlEncoder.class, ReflectionUtil.getFieldValue(encryptor, "textEncoder").getClass());
		assertEquals(Base32Encoder.class, ReflectionUtil.getFieldValue(parameters, "textEncoder").getClass());
		assertEquals(key, Base32Encoder.getInstance().encode(parameters.getKey().getEncoded()));
		assertEquals(providerName, parameters.getProviderName());
		assertEquals(BlowfishParameters.MAC_ALGORITHM_HMAC_SHA1, parameters.getMacAlgorithm());
		assertEquals(macKey, Base32Encoder.getInstance().encode(parameters.getMacKey().getEncoded()));
		assertEquals(BlowfishParameters.BLOCK_MODE_OFB, parameters.getBlockMode());
		assertEquals(Integer.valueOf(blockSize), (Integer)parameters.getBlockSize());
		assertEquals(BlowfishParameters.PADDING_NONE, parameters.getPadding());

		properties.rollback();
	}

	private String getPropertyName(final String prefix, final String key) {
		return prefix == null ? key : prefix + "." + key;
	}

}
