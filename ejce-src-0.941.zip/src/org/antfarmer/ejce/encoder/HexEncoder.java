/*
 * Copyright 2006-2007 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.antfarmer.ejce.encoder;

/**
 * Encoder for encoding/decoding bytes and text using the hexadecimal (Base-16) format. This format
 * results in a 100% increase in output length. The character set includes: [A-F0-9]. <b>This class
 * is thread-safe.</b>
 * 
 * @author Ameer Antar
 * @version 1.0
 */
public class HexEncoder implements TextEncoder {
	/**
	 * Array of characters used to represent a number in base-16.
	 */
	protected final char[] HEX_CHARS = new char[HEX_RADIX];
	
	private static final int HEX_RADIX = 16;

	private static final int STRING_BUFF_CAPACITY_OFFSET = 5;
	
	private static final HexEncoder instance = new HexEncoder();

	/**
	 * Initializes the HexEncoder.
	 */
	protected HexEncoder() {
		for (int i=0; i<10; i++) {
			HEX_CHARS[i] = (char) (0x30 + i);
		}
		for (int i=0; i<6; i++) {
			HEX_CHARS[i+10] = (char) (0x41 + i);
		}
	}

	/**
	 * Returns an instance of a HexEncoder.
	 * @return an instance of a HexEncoder
	 */
	public static HexEncoder getInstance() {
		return instance;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see org.antfarmer.ejce.encoder.TextEncoder#encode(byte[])
	 */
	public String encode(final byte[] bytes) {
		if (bytes == null) {
			return null;
		}
		int i, imax = bytes.length;
		StringBuilder buff = new StringBuilder((imax << 1) + STRING_BUFF_CAPACITY_OFFSET);
		for (i = 0; i < imax; i++) {
			int b = bytes[i] & 0xFF;
			buff.append(HEX_CHARS[b >> 4]);
			buff.append(HEX_CHARS[b & 0x0F]);
		}
		return buff.toString();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see org.antfarmer.ejce.encoder.TextEncoder#decode(java.lang.String)
	 */
	public byte[] decode(final String text) {
		if (text == null) {
			return null;
		}
		int i, imax = text.length(), j = 0;
		if (imax % 2 != 0) {
			throw new IllegalArgumentException(
					"Hex encoded string does not contain even number of characters.");
		}
		byte[] bytes = new byte[imax / 2];
		for (i = 0; i < imax; i += 2) {
			byte b = (byte) (Integer.parseInt(String.valueOf(text.charAt(i)), HEX_RADIX) << 4);
			b += Integer.parseInt(String.valueOf(text.charAt(i + 1)), HEX_RADIX);
			bytes[j++] = b;
		}
		return bytes;
	}

}
