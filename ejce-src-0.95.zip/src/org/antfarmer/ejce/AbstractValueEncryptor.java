/*
 * Copyright 2006-2007 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.antfarmer.ejce;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.GeneralSecurityException;

import org.antfarmer.ejce.encoder.HexEncoder;
import org.antfarmer.ejce.encoder.TextEncoder;
import org.antfarmer.ejce.util.ByteUtil;

/**
 * Abstract class for encrypting/decrypting text and other values.
 *
 * @author Ameer Antar
 * @version 1.2
 * @param <T> the concrete type of this encryptor object.
 */
public abstract class AbstractValueEncryptor<T extends AbstractValueEncryptor<T>>
		extends AbstractEncryptor<T> implements ValueEncryptorInterface<T> {

	private final TextEncoder textEncoder;

	/**
	 * Initializes the AbstractValueEncryptor with a {@link HexEncoder} used for encoding/decoding byte
	 * arrays.
	 */
	public AbstractValueEncryptor() {
		this.textEncoder = HexEncoder.getInstance();
	}

	/**
	 * Initializes the AbstractValueEncryptor with the given {@link TextEncoder} used for
	 * encoding/decoding byte arrays.
	 *
	 * @param textEncoder the {@link TextEncoder} used for encoding/decoding byte arrays
	 */
	public AbstractValueEncryptor(final TextEncoder textEncoder) {
		this.textEncoder = textEncoder;
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#encrypt(java.lang.String)
	 */
	public String encrypt(final String text) throws GeneralSecurityException {
		if (text == null) {
			return null;
		}
		return textEncoder.encode(encrypt(text.getBytes()));
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#decrypt(java.lang.String)
	 */
	public String decrypt(final String text) throws GeneralSecurityException {
		if (text == null) {
			return null;
		}
		return new String(decrypt(textEncoder.decode(text)));
	}

	/**
	 * {@inheritDoc}
	 */
	public String encryptAndEncode(final byte[] bytes) throws GeneralSecurityException {
		if (bytes == null) {
			return null;
		}
		return textEncoder.encode(encrypt(bytes));
	}

	/**
	 * {@inheritDoc}
	 */
	public byte[] decryptAndDecode(final String text) throws GeneralSecurityException {
		if (text == null) {
			return null;
		}
		return decrypt(textEncoder.decode(text));
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#encryptCharacter(java.lang.Character)
	 */
	public String encryptCharacter(final Character number)
			throws GeneralSecurityException {
		if (number == null) {
			return null;
		}
		return textEncoder.encode(encrypt(String.valueOf(number).getBytes()));
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#decryptCharacter(java.lang.String)
	 */
	public Character decryptCharacter(final String text)
			throws GeneralSecurityException {
		if (text == null) {
			return null;
		}
		return new String(decrypt(textEncoder.decode(text))).charAt(0);
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#encryptLong(java.lang.Long)
	 */
	public String encryptLong(final Long number) throws GeneralSecurityException {
		if (number == null) {
			return null;
		}
		return textEncoder.encode(encrypt(ByteUtil.toBytes(number)));
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#decryptLong(java.lang.String)
	 */
	public Long decryptLong(final String text) throws GeneralSecurityException {
		if (text == null) {
			return null;
		}
		return ByteUtil.toLong(decrypt(textEncoder.decode(text)));
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#encryptInteger(java.lang.Integer)
	 */
	public String encryptInteger(final Integer number)
			throws GeneralSecurityException {
		if (number == null) {
			return null;
		}
		return textEncoder.encode(encrypt(ByteUtil.toBytes(number)));
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#decryptInteger(java.lang.String)
	 */
	public Integer decryptInteger(final String text) throws GeneralSecurityException {
		if (text == null) {
			return null;
		}
		return ByteUtil.toInt(decrypt(textEncoder.decode(text)));
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#encryptShort(java.lang.Short)
	 */
	public String encryptShort(final Short number) throws GeneralSecurityException {
		if (number == null) {
			return null;
		}
		return textEncoder.encode(encrypt(ByteUtil.toBytes(number)));
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#decryptShort(java.lang.String)
	 */
	public Short decryptShort(final String text) throws GeneralSecurityException {
		if (text == null) {
			return null;
		}
		return ByteUtil.toShort(decrypt(textEncoder.decode(text)));
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#encryptBoolean(java.lang.Boolean)
	 */
	public String encryptBoolean(final Boolean value)
			throws GeneralSecurityException {
		if (value == null) {
			return null;
		}
		return textEncoder.encode(encrypt(new byte[] {(byte) (value ? 1 : 0)}));
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#decryptBoolean(java.lang.String)
	 */
	public Boolean decryptBoolean(final String text) throws GeneralSecurityException {
		if (text == null) {
			return null;
		}
		return decrypt(textEncoder.decode(text))[0] == 1 ? true : false;
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#encryptDouble(java.lang.Double)
	 */
	public String encryptDouble(final Double number) throws GeneralSecurityException {
		if (number == null) {
			return null;
		}
		return textEncoder.encode(encrypt(ByteUtil.toBytes(number)));
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#decryptDouble(java.lang.String)
	 */
	public Double decryptDouble(final String text) throws GeneralSecurityException {
		if (text == null) {
			return null;
		}
		return ByteUtil.toDouble(decrypt(textEncoder.decode(text)));
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#encryptFloat(java.lang.Float)
	 */
	public String encryptFloat(final Float number) throws GeneralSecurityException {
		if (number == null) {
			return null;
		}
		return textEncoder.encode(encrypt(ByteUtil.toBytes(number)));
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#decryptFloat(java.lang.String)
	 */
	public Float decryptFloat(final String text) throws GeneralSecurityException {
		if (text == null) {
			return null;
		}
		return ByteUtil.toFloat(decrypt(textEncoder.decode(text)));
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#encryptObject(java.lang.Object)
	 */
	public String encryptObject(final Object object)
			throws GeneralSecurityException, IOException {
		if (object == null) {
			return null;
		}
		final ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ObjectOutputStream oos = null;
		try {
			oos = new ObjectOutputStream(baos);
			oos.writeObject(object);
		}
		catch (final IOException e) {
			throw e;
		}
		finally {
			if (oos != null) {
				oos.close();
			}
		}
		return textEncoder.encode(encrypt(baos.toByteArray()));
	}

	/**
	 * {@inheritDoc}
	 * @see org.antfarmer.ejce.ValueEncryptorInterface#decryptObject(java.lang.String)
	 */
	public Object decryptObject(final String text)
			throws GeneralSecurityException, IOException, ClassNotFoundException {
		if (text == null) {
			return null;
		}
		Object object;
		final ByteArrayInputStream bais = new ByteArrayInputStream(decrypt(textEncoder.decode(text)));
		ObjectInputStream ois = null;
		try {
			ois = new ObjectInputStream(bais);
			object = ois.readObject();
		}
		catch (final IOException e) {
			throw e;
		}
		finally {
			if (ois != null) {
				ois.close();
			}
		}
		return object;
	}

}
