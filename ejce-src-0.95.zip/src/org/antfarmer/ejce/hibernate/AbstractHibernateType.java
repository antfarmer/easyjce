/*
 * Copyright 2006-2007 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.antfarmer.ejce.hibernate;

import java.io.Serializable;
import java.security.GeneralSecurityException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.concurrent.locks.ReentrantLock;

import org.antfarmer.ejce.Encryptor;
import org.antfarmer.ejce.EncryptorConfigurationException;
import org.antfarmer.ejce.ValueEncryptorInterface;
import org.antfarmer.ejce.util.ConfigurerUtil;
import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.usertype.ParameterizedType;
import org.hibernate.usertype.UserType;
import org.hibernate.util.EqualsHelper;


/**
 * Abstract Hibernate UserType class which encrypts and decrypts values transparently. This ensures
 * data is stored in it's encrypted form in persistent storage, while not affecting it's real value
 * in the application.
 *
 * @author Ameer Antar
 * @version 1.2
 */
public abstract class AbstractHibernateType implements UserType, ParameterizedType {

	private static final int[] sqlTypes = new int[] { Hibernate.STRING.sqlType() };

	private ValueEncryptorInterface<Encryptor> encryptor;

	private final ReentrantLock lock = new ReentrantLock();

	/**
	 * Encrypts the given object using an appropriate method for the object type.
	 *
	 * @param value the object to be encrypted
	 * @return a string representation of the encrypted and encoded object
	 * @throws GeneralSecurityException GeneralSecurityException
	 */
	protected abstract String encrypt(Object value) throws GeneralSecurityException;

	/**
	 * Decrypts the given string using an appropriate method for the object type.
	 *
	 * @param value the string to be decrypted
	 * @return the decrypted object
	 * @throws GeneralSecurityException GeneralSecurityException
	 */
	protected abstract Object decrypt(String value) throws GeneralSecurityException;

	/**
	 * {@inheritDoc}
	 *
	 * @see org.hibernate.usertype.UserType#assemble(java.io.Serializable, java.lang.Object)
	 */
	public Object assemble(final Serializable cached, final Object owner) throws HibernateException {
		if (cached == null) {
			return null;
		}
		return deepCopy(cached);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see org.hibernate.usertype.UserType#deepCopy(java.lang.Object)
	 */
	public Object deepCopy(final Object value) throws HibernateException {
		return value;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see org.hibernate.usertype.UserType#disassemble(java.lang.Object)
	 */
	public Serializable disassemble(final Object value) throws HibernateException {
		if (value == null) {
			return null;
		}
		return (Serializable) deepCopy(value);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see org.hibernate.usertype.UserType#equals(java.lang.Object, java.lang.Object)
	 */
	public boolean equals(final Object x, final Object y) throws HibernateException {
		return EqualsHelper.equals(x, y);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see org.hibernate.usertype.UserType#hashCode(java.lang.Object)
	 */
	public int hashCode(final Object x) throws HibernateException {
		return x.hashCode();
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see org.hibernate.usertype.UserType#isMutable()
	 */
	public boolean isMutable() {
		return false;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see org.hibernate.usertype.UserType#nullSafeGet(java.sql.ResultSet, java.lang.String[],
	 *      java.lang.Object)
	 */
	public Object nullSafeGet(final ResultSet rs, final String[] names, final Object owner)
			throws HibernateException, SQLException {
		final String text = rs.getString(names[0]);
		try {
			return rs.wasNull() || text.length() < 1 ? null : decrypt(text);
		}
		catch (final GeneralSecurityException e) {
			throw new EncryptorConfigurationException("Error decrypting object.", e);
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see org.hibernate.usertype.UserType#nullSafeSet(java.sql.PreparedStatement,
	 *      java.lang.Object, int)
	 */
	public void nullSafeSet(final PreparedStatement st, final Object value, final int index)
			throws HibernateException, SQLException {
		if (value == null) {
			st.setNull(index, Hibernate.STRING.sqlType());
		}
		else {
			try {
				st.setString(index, encrypt(value));
			}
			catch (final GeneralSecurityException e) {
				throw new EncryptorConfigurationException("Error encrypting object.", e);
			}
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see org.hibernate.usertype.UserType#replace(java.lang.Object, java.lang.Object,
	 *      java.lang.Object)
	 */
	public Object replace(final Object original, final Object target, final Object owner) throws HibernateException {
		return original;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see org.hibernate.usertype.UserType#sqlTypes()
	 */
	public int[] sqlTypes() {
		return sqlTypes;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see org.hibernate.usertype.ParameterizedType#setParameterValues(java.util.Properties)
	 */
	public void setParameterValues(final Properties parameters) {
		lock.lock();
		try {
			encryptor = ConfigurerUtil.configureEncryptor(parameters);
			initializeIfNot();
		}
		finally {
			lock.unlock();
		}
	}

	private void initializeIfNot() {
		try {
			encryptor.initialize();
		}
		catch (final GeneralSecurityException e) {
			throw new EncryptorConfigurationException("Error initializing cipher for Hibernate Usertype.", e);
		}
	}

	/**
	 * Returns the encryptor value.
	 *
	 * @return Returns the encryptor.
	 */
	protected ValueEncryptorInterface<Encryptor> getEncryptor() {
		return encryptor;
	}

}
