/*
 * Copyright 2006-2007 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.antfarmer.ejce.util;

import java.security.Provider;
import java.util.Properties;

import org.antfarmer.ejce.Encryptor;
import org.antfarmer.ejce.EncryptorConfigurationException;
import org.antfarmer.ejce.EncryptorStore;
import org.antfarmer.ejce.encoder.Base64Encoder;
import org.antfarmer.ejce.encoder.TextEncoder;
import org.antfarmer.ejce.parameter.AbstractBlockCipherParameters;
import org.antfarmer.ejce.parameter.AlgorithmParameters;
import org.antfarmer.ejce.parameter.PbeParameters;

/**
 *
 * @author Ameer Antar
 * @version 1.0
 */
public final class ConfigurerUtil {

	/**
	 * Property key for the prefix to be used to lookup configuration settings within the system properties.
	 */
	public static final String KEY_PROPERTY_PREFIX = "propertyPrefix";

	/**
	 * Property key for the {@link EncryptorStore} key which maps to a code-configured {@link Encryptor}.
	 */
	public static final String KEY_ENCRYPTOR_STORE_KEY = "storeKey";

	/**
	 * Property key for the full class name of the {@link TextEncoder} to be used with the {@link Encryptor}.
	 */
	public static final String KEY_ENCODER_CLASS = "encoder";

	/**
	 * Property key for the full class name of the algorithm parameter class to be used to configure the
	 * {@link Encryptor}.
	 */
	public static final String KEY_PARAM_CLASS = "paramClass";

	/**
	 * Property key for the full class name of the {@link TextEncoder} to be used with the algorithm parameter object.
	 */
	public static final String KEY_PARAM_ENCODER_CLASS = "paramEncoder";

	/**
	 * Property key for the encryption key to be used to configure the {@link Encryptor}.
	 */
	public static final String KEY_ENCRYPTION_KEY = "key";

	/**
	 * Property key for the encryption algorithm to be used to configure the {@link Encryptor}.
	 */
	public static final String KEY_ALGORITHM = "algorithm";

	/**
	 * Property key for the JCE provider name to be used with the {@link Encryptor}.
	 */
	public static final String KEY_PROVIDER_NAME = "providerName";

	/**
	 * Property key for the JCE provider class to be used with the {@link Encryptor}.
	 */
	public static final String KEY_PROVIDER_CLASS = "providerClass";

	/**
	 * Property key for the MAC key to be used to configure the {@link Encryptor}.
	 */
	public static final String KEY_MAC_KEY = "macKey";

	/**
	 * Property key for the MAC algorithm to be used to configure the {@link Encryptor}.
	 */
	public static final String KEY_MAC_ALGORITHM = "macAlgorithm";

	/**
	 * Property key for the block mode to be used with the encryption algorithm.
	 */
	public static final String KEY_BLOCK_MODE = "blockMode";

	/**
	 * Property key for the block size to be used with the encryption algorithm.
	 */
	public static final String KEY_BLOCK_SIZE = "blockSize";

	/**
	 * Property key for the padding to be used with the encryption algorithm.
	 */
	public static final String KEY_PADDING = "padding";

	/**
	 * Property key for the salt size (in bytes) to be used with a PBE algorithm.
	 */
	public static final String KEY_SALT_SIZE = "saltSize";

	/**
	 * Property key for the number of PBE iterations to be used with a PBE algorithm.
	 */
	public static final String KEY_ITERATION_COUNT = "iterations";

	private static final String METHOD_ENCODER_GET_INSTANCE = "getInstance";

	private static final String FIELD_TEXT_ENCODER = "textEncoder";

	private static final String FIELD_ALGORITHM = "algorithm";

	private ConfigurerUtil() {
		// static methods only
	}

	/**
	 * Loads and configures an encryptor based on settings within the given properties.
	 *
	 * @param properties the properties with encryptor settings
	 * @return an encryptor based on settings within the given properties
	 */
	public static Encryptor configureEncryptor(final Properties properties) {
		return configureEncryptor(properties, null);
	}

	/**
	 * Loads and configures an encryptor based on settings within the given properties. The prefix is prepended on each
	 * of the property keys.
	 *
	 * @param properties the properties with encryptor settings
	 * @param prefix prefix to be used with the property keys
	 * @return an encryptor based on settings within the given properties
	 */
	public static Encryptor configureEncryptor(final Properties properties, final String prefix) {
		Encryptor encryptor;

		// get encryptor settings from system properties
		String property = properties.getProperty(getPropertyName(prefix, KEY_PROPERTY_PREFIX));
		if (property != null) {
			if (properties == System.getProperties()) {
				throw new EncryptorConfigurationException("Cannot set " + KEY_PROPERTY_PREFIX
						+ " within system properties.");
			}
			return configureEncryptor(System.getProperties(), property);
		}

		// get encryptor from store if encryptor name is set
		property = properties.getProperty(getPropertyName(prefix, KEY_ENCRYPTOR_STORE_KEY));
		if (property != null) {
			encryptor = EncryptorStore.get(property);
			if (encryptor == null) {
				throw new EncryptorConfigurationException("Could not find encryptor in store with name: "
						+ property);
			}
			return encryptor;
		}

		// instantiate text encoder for encryptor
		TextEncoder encoder = null;
		property = properties.getProperty(getPropertyName(prefix, KEY_ENCODER_CLASS));
		if (property == null) {
			property = Base64Encoder.class.getName();
		}
		try {
			encoder = (TextEncoder) Class.forName(property).getMethod(METHOD_ENCODER_GET_INSTANCE).invoke(null);
		}
		catch (final Exception e) {
			throw new EncryptorConfigurationException("Error instantiating: " + property, e);
		}

		// prepare encryptor using mapping file parameters
		encryptor = new Encryptor(encoder);
		return encryptor.setAlgorithmParameters(loadAlgorithmParameters(properties, prefix));
	}

	private static AlgorithmParameters<?> loadAlgorithmParameters(final Properties parameters, final String prefix) {
		AlgorithmParameters<?> algorithmParameters = null;
		String property;

		// instantiate algorithmParameters
		property = parameters.getProperty(getPropertyName(prefix, KEY_PARAM_CLASS));
		if (property == null) {
			throw new EncryptorConfigurationException("Missing '" + KEY_PARAM_CLASS
					+ "' property in Hibernate mapping.");
		}
		try {
			algorithmParameters = (AlgorithmParameters<?>) Class.forName(property).newInstance();
		}
		catch (final Exception e) {
			throw new EncryptorConfigurationException("Error instantiating: " + property, e);
		}

		// instantiate text encoder if necessary
		property = parameters.getProperty(getPropertyName(prefix, KEY_PARAM_ENCODER_CLASS));
		if (property != null) {
			try {
				final TextEncoder encoder = (TextEncoder) Class.forName(property).getMethod(METHOD_ENCODER_GET_INSTANCE).invoke(null);
				ReflectionUtil.setFieldValue(algorithmParameters, encoder, FIELD_TEXT_ENCODER);
			}
			catch (final Exception e) {
				throw new EncryptorConfigurationException("Error instantiating: " + property, e);
			}
		}

		// set key
		property = parameters.getProperty(getPropertyName(prefix, KEY_ENCRYPTION_KEY));
		if (property == null) {
			throw new EncryptorConfigurationException("Missing '" + KEY_ENCRYPTION_KEY
					+ "' property in Hibernate mapping.");
		}
		algorithmParameters.setKey(property);

		// set algorithm
		property = parameters.getProperty(getPropertyName(prefix, KEY_ALGORITHM));
		if (property != null) {
			try {
				ReflectionUtil.setFieldValue(algorithmParameters, property, FIELD_ALGORITHM);
			}
			catch (final Exception e) {
				throw new EncryptorConfigurationException("Error setting '" + FIELD_ALGORITHM + "' on "
						+ algorithmParameters.getClass().getSimpleName(), e);
			}
		}

		// set providerName
		property = parameters.getProperty(getPropertyName(prefix, KEY_PROVIDER_NAME));
		if (property != null) {
			algorithmParameters.setProviderName(property);
		}

		// set provider
		property = parameters.getProperty(getPropertyName(prefix, KEY_PROVIDER_CLASS));
		if (property != null) {
			try {
				algorithmParameters.setProvider((Provider) Class.forName(property).newInstance());
			}
			catch (final Exception e) {
				throw new EncryptorConfigurationException("Error instantiating: " + property, e);
			}
		}

		// set mac key
		property = parameters.getProperty(getPropertyName(prefix, KEY_MAC_KEY));
		if (property != null) {
			algorithmParameters.setMacKey(property);
		}

		// set mac algorithm
		property = parameters.getProperty(getPropertyName(prefix, KEY_MAC_ALGORITHM));
		if (property != null) {
			algorithmParameters.setMacAlgorithm(property);
		}

		// if not a block cipher, return
		if (!(algorithmParameters instanceof AbstractBlockCipherParameters)) {
			return algorithmParameters;
		}
		final AbstractBlockCipherParameters<?> blockCipherParameters = (AbstractBlockCipherParameters<?>) algorithmParameters;

		// set block mode
		property = parameters.getProperty(getPropertyName(prefix, KEY_BLOCK_MODE));
		if (property != null) {
			blockCipherParameters.setBlockMode(property);
		}

		// set block size
		property = parameters.getProperty(getPropertyName(prefix, KEY_BLOCK_SIZE));
		if (property != null) {
			blockCipherParameters.setBlockSize(Integer.valueOf(property));
		}

		// set block padding
		property = parameters.getProperty(getPropertyName(prefix, KEY_PADDING));
		if (property != null) {
			blockCipherParameters.setPadding(property);
		}

		// if not a PBE cipher, return
		if (!(algorithmParameters instanceof PbeParameters)) {
			return algorithmParameters;
		}
		final PbeParameters pbeParameters = (PbeParameters) algorithmParameters;

		// set salt size
		property = parameters.getProperty(getPropertyName(prefix, KEY_SALT_SIZE));
		if (property != null) {
			pbeParameters.setSaltSize(Integer.valueOf(property));
		}

		// set iteration count
		property = parameters.getProperty(getPropertyName(prefix, KEY_ITERATION_COUNT));
		if (property != null) {
			pbeParameters.setIterationCount(Integer.valueOf(property));
		}

		return algorithmParameters;
	}

	private static String getPropertyName(final String prefix, final String baseName) {
		return prefix == null ? baseName : prefix + "." + baseName;
	}

}
