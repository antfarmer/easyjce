/*
 * Copyright 2006-2007 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.antfarmer.ejce.encoder;

import java.util.regex.Pattern;

/**
 * Encoder for encoding/decoding bytes and text using the Base-64 format without padding. The
 * character set includes: [A-Za-z0-9+/]. This format results in a 33% increase in output length at
 * best. <b>This class is thread-safe.</b>
 * 
 * @author Ameer Antar
 * @version 1.2
 */
public class Base64Encoder implements TextEncoder {

	/**
	 * Array used for encoding text to Base64.
	 */
	protected final byte[] ENCODE_ARRAY = new byte[64];

	/**
	 * Array used for decoding text from Base64.
	 */
	protected final byte[] DECODE_ARRAY = new byte[123];

	/**
	 * Character to be used for padding Base64 encoded text.
	 */
	protected byte PADDING_CHAR = '=';

	/**
	 * Indicates whether padding should be used for encoding/decoding data.
	 */
	protected boolean usePadding;

	private static final Pattern WHITE_SPACE_PATTERN = Pattern.compile("\\s");

	private static final Base64Encoder instance = new Base64Encoder();

	/**
	 * Initializes the Base64Encoder.
	 */
	protected Base64Encoder() {
		// setup encode array
		for (int i = 0; i < 26; i++)
			ENCODE_ARRAY[i] = (byte) (i + 65);
		for (int i = 26; i < 52; i++)
			ENCODE_ARRAY[i] = (byte) (i + 71);
		for (int i = 52; i < 62; i++)
			ENCODE_ARRAY[i] = (byte) (i - 4);
		ENCODE_ARRAY[62] = '+';
		ENCODE_ARRAY[63] = '/';

		// setup decode array
		DECODE_ARRAY[43] = 62;
		DECODE_ARRAY[47] = 63;
		for (int i = 48; i < 58; i++)
			DECODE_ARRAY[i] = (byte) (i + 4);
		for (int i = 65; i < 91; i++)
			DECODE_ARRAY[i] = (byte) (i - 65);
		for (int i = 97; i < 123; i++)
			DECODE_ARRAY[i] = (byte) (i - 71);
	}

	/**
	 * Returns an instance of a Base64Encoder.
	 * 
	 * @return an instance of a Base64Encoder
	 */
	public static Base64Encoder getInstance() {
		return instance;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see org.antfarmer.ejce.encoder.TextEncoder#encode(byte[])
	 */
	public String encode(final byte[] bytes) {
		if (bytes == null)
			return null;
		String ret = new String();

		int originalSize = bytes.length;
		if (originalSize < 1) {
			return ret;
		}

		int i;
		// convert bytes to unsigned chars
		char[] chars = new char[originalSize];
		for (i = 0; i < originalSize; i++) {
			if (bytes[i] < 0)
				chars[i] = (char) (bytes[i] + 256);
			else
				chars[i] = (char) bytes[i];
		}

		byte[] encodedBytes;
		int remainder = originalSize % 3;
		if (remainder == 0)
			encodedBytes = new byte[((originalSize << 2) / 3)];
		else {
			if (!usePadding) {
				encodedBytes = new byte[(int) Math.ceil((originalSize << 2) / 3.0)];
			}
			else {
				encodedBytes = new byte[(((originalSize + 3 - remainder) << 2) / 3)];
			}
			originalSize -= remainder;
		}

		int k = 0;
		for (i = 0; i < originalSize; i += 3) {
			encodedBytes[k] = ENCODE_ARRAY[chars[i] >> 2];
			encodedBytes[k + 1] = ENCODE_ARRAY[((chars[i] & 0x03) << 4) + (chars[i + 1] >> 4)];
			encodedBytes[k + 2] = ENCODE_ARRAY[((chars[i + 1] & 0x0F) << 2) + (chars[i + 2] >> 6)];
			encodedBytes[k + 3] = ENCODE_ARRAY[chars[i + 2] & 0x3F];
			k += 4;
		}

		if (remainder == 1) {
			// 1 extra byte
			encodedBytes[k] = ENCODE_ARRAY[chars[i] >> 2];
			encodedBytes[k + 1] = ENCODE_ARRAY[(chars[i] & 0x03) << 4];
			if (usePadding) {
				encodedBytes[k + 2] = PADDING_CHAR;
				encodedBytes[k + 3] = PADDING_CHAR;
			}
		}
		else if (remainder == 2) {
			// 2 extra bytes
			encodedBytes[k] = ENCODE_ARRAY[chars[i] >> 2];
			encodedBytes[k + 1] = ENCODE_ARRAY[((chars[i] & 0x03) << 4) + (chars[i + 1] >> 4)];
			encodedBytes[k + 2] = ENCODE_ARRAY[((chars[i + 1] & 0x0F) << 2)];
			if (usePadding) {
				encodedBytes[k + 3] = PADDING_CHAR;
			}
		}

		return new String(encodedBytes);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see org.antfarmer.ejce.encoder.TextEncoder#decode(java.lang.String)
	 */
	public byte[] decode(final String text) {
		if (text == null)
			return null;

		// cleanup input string
		String encodedText = WHITE_SPACE_PATTERN.matcher(text).replaceAll("");
		int originalSize = encodedText.length();
		if (originalSize < 1) {
			return new byte[0];
		}
		if (usePadding && originalSize % 4 != 0) {
			throw new IllegalArgumentException(
					"Encoded string does not match Base-64 format with padding.");
		}

		int newSize = (originalSize * 3) >> 2;
		int remainder = 4;
		if (usePadding) {
			int p = encodedText.indexOf(PADDING_CHAR);
			if (p > 0)
				newSize -= originalSize - p;
		}
		else {
			int m = originalSize % 4;
			if (m > 0)
				remainder = m;
		}
		byte[] byteArr = new byte[newSize];
		originalSize -= 4;

		int i, j = 0;
		byte[] hexArr = new byte[4];
		for (i = 0; i < originalSize; i += 4) {
			for (int k = 0; k < 4; k++)
				hexArr[k] = DECODE_ARRAY[encodedText.charAt(i + k)];
			byteArr[j] = (byte) (hexArr[0] << 2);
			byteArr[j] += (hexArr[1] >> 4);
			byteArr[j + 1] = (byte) (hexArr[1] << 4);
			byteArr[j + 1] += (hexArr[2] >> 2);
			byteArr[j + 2] = (byte) (hexArr[2] << 6);
			byteArr[j + 2] += hexArr[3];
			j += 3;
		}

		for (int k = 0; k < remainder; k++)
			hexArr[k] = DECODE_ARRAY[encodedText.charAt(i + k)];
		byteArr[j] = (byte) (hexArr[0] << 2);
		byteArr[j] += (hexArr[1] >> 4);
		if (newSize > j + 1) {
			byteArr[j + 1] = (byte) (hexArr[1] << 4);
			byteArr[j + 1] += (hexArr[2] >> 2);
		}
		if (newSize > j + 2) {
			byteArr[j + 2] = (byte) (hexArr[2] << 6);
			byteArr[j + 2] += hexArr[3];
		}

		return byteArr;
	}

	/**
	 * Sets the usePadding value which indicates whether padding should be used for
	 * encoding/decoding data.
	 * 
	 * @param usePadding The usePadding value to set.
	 * @return this Base64Encoder
	 */
	protected Base64Encoder setUsePadding(boolean usePadding) {
		this.usePadding = usePadding;
		return this;
	}

}