/*
 * Copyright 2006-2007 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.antfarmer.ejce.encoder;

import java.util.regex.Pattern;

/**
 * Encoder for encoding/decoding bytes and text using the Base-32 format without padding. The
 * encoded results contain only US-ASCII letters and numbers. The character set includes: [A-Z2-7].
 * This format results in a 60% increase in output length at best. <b>This class is thread-safe.</b>
 * 
 * @author Ameer Antar
 * @version 1.1
 */
public class Base32Encoder implements TextEncoder {

	/**
	 * Array used for encoding text to Base32.
	 */
	protected final byte[] ENCODE_ARRAY = new byte[32];

	/**
	 * Array used for decoding text from Base32.
	 */
	protected final byte[] DECODE_ARRAY = new byte[121];

	/**
	 * Character to be used for padding Base32 encoded text.
	 */
	protected byte PADDING_CHAR = '=';

	/**
	 * Indicates whether padding should be used for encoding/decoding data.
	 */
	private boolean usePadding;

	private static final Pattern WHITE_SPACE_PATTERN = Pattern.compile("\\s");
	
	private static final Base32Encoder instance = new Base32Encoder();

	/**
	 * Initializes the Base32Encoder.
	 */
	protected Base32Encoder() {
		// setup encode array
		for (int i = 0; i < 26; i++)
			ENCODE_ARRAY[i] = (byte) (i + 65);
		for (int i = 26; i < 32; i++)
			ENCODE_ARRAY[i] = (byte) (i + 24);

		// setup decode array
		for (int i = 65; i < 91; i++)
			DECODE_ARRAY[i] = (byte) (i - 65);
		for (int i = 50; i < 56; i++)
			DECODE_ARRAY[i] = (byte) (i - 24);
	}
	
	/**
	 * Returns an instance of a Base32Encoder.
	 * @return an instance of a Base32Encoder
	 */
	public static Base32Encoder getInstance() {
		return instance;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see org.antfarmer.ejce.encoder.TextEncoder#encode(byte[])
	 */
	public String encode(final byte[] bytes) {
		if (bytes == null)
			return null;
		String ret = new String();

		int originalSize = bytes.length;
		if (originalSize < 1) {
			return ret;
		}

		int i;
		// convert bytes to unsigned chars
		char[] chars = new char[originalSize];
		for (i = 0; i < originalSize; i++) {
			if (bytes[i] < 0)
				chars[i] = (char) (bytes[i] + 256);
			else
				chars[i] = (char) bytes[i];
		}

		byte[] encodedBytes;
		int remainder = originalSize % 5;
		if (remainder == 0) {
			encodedBytes = new byte[((originalSize << 3) / 5)];
		}
		else {
			if (!usePadding) {
				encodedBytes = new byte[(int) Math.ceil((originalSize << 3) / 5.0)];
			}
			else {
				encodedBytes = new byte[(((originalSize + 5 - remainder) << 3) / 5)];
			}
			originalSize -= remainder;
		}

		int k = 0;
		for (i = 0; i < originalSize; i += 5) {
			encodedBytes[k] = ENCODE_ARRAY[chars[i] >> 3];
			encodedBytes[k + 1] = ENCODE_ARRAY[((chars[i] & 0x07) << 2) + (chars[i + 1] >> 6)];
			encodedBytes[k + 2] = ENCODE_ARRAY[((chars[i + 1] & 0x3F) >> 1)];
			encodedBytes[k + 3] = ENCODE_ARRAY[((chars[i + 1] & 0x01) << 4) + (chars[i + 2] >> 4)];
			encodedBytes[k + 4] = ENCODE_ARRAY[((chars[i + 2] & 0x0F) << 1) + (chars[i + 3] >> 7)];
			encodedBytes[k + 5] = ENCODE_ARRAY[((chars[i + 3] & 0x7F) >> 2)];
			encodedBytes[k + 6] = ENCODE_ARRAY[((chars[i + 3] & 0x03) << 3) + (chars[i + 4] >> 5)];
			encodedBytes[k + 7] = ENCODE_ARRAY[(chars[i + 4] & 0x1F)];
			k += 8;
		}

		if (remainder == 1) {
			// 1 extra byte
			encodedBytes[k] = ENCODE_ARRAY[chars[i] >> 3];
			encodedBytes[k + 1] = ENCODE_ARRAY[((chars[i] & 0x07) << 2)];
			if (usePadding) {
				encodedBytes[k + 2] = PADDING_CHAR;
				encodedBytes[k + 3] = PADDING_CHAR;
				encodedBytes[k + 4] = PADDING_CHAR;
				encodedBytes[k + 5] = PADDING_CHAR;
				encodedBytes[k + 6] = PADDING_CHAR;
				encodedBytes[k + 7] = PADDING_CHAR;
			}
		}
		else if (remainder == 2) {
			// 2 extra bytes
			encodedBytes[k] = ENCODE_ARRAY[chars[i] >> 3];
			encodedBytes[k + 1] = ENCODE_ARRAY[((chars[i] & 0x07) << 2) + (chars[i + 1] >> 6)];
			encodedBytes[k + 2] = ENCODE_ARRAY[((chars[i + 1] & 0x3F) >> 1)];
			encodedBytes[k + 3] = ENCODE_ARRAY[((chars[i + 1] & 0x01) << 4)];
			if (usePadding) {
				encodedBytes[k + 4] = PADDING_CHAR;
				encodedBytes[k + 5] = PADDING_CHAR;
				encodedBytes[k + 6] = PADDING_CHAR;
				encodedBytes[k + 7] = PADDING_CHAR;
			}
		}
		else if (remainder == 3) {
			// 3 extra bytes
			encodedBytes[k] = ENCODE_ARRAY[chars[i] >> 3];
			encodedBytes[k + 1] = ENCODE_ARRAY[((chars[i] & 0x07) << 2) + (chars[i + 1] >> 6)];
			encodedBytes[k + 2] = ENCODE_ARRAY[((chars[i + 1] & 0x3F) >> 1)];
			encodedBytes[k + 3] = ENCODE_ARRAY[((chars[i + 1] & 0x01) << 4) + (chars[i + 2] >> 4)];
			encodedBytes[k + 4] = ENCODE_ARRAY[((chars[i + 2] & 0x0F) << 1)];
			if (usePadding) {
				encodedBytes[k + 5] = PADDING_CHAR;
				encodedBytes[k + 6] = PADDING_CHAR;
				encodedBytes[k + 7] = PADDING_CHAR;
			}
		}
		else if (remainder == 4) {
			// 4 extra bytes
			encodedBytes[k] = ENCODE_ARRAY[chars[i] >> 3];
			encodedBytes[k + 1] = ENCODE_ARRAY[((chars[i] & 0x07) << 2) + (chars[i + 1] >> 6)];
			encodedBytes[k + 2] = ENCODE_ARRAY[((chars[i + 1] & 0x3F) >> 1)];
			encodedBytes[k + 3] = ENCODE_ARRAY[((chars[i + 1] & 0x01) << 4) + (chars[i + 2] >> 4)];
			encodedBytes[k + 4] = ENCODE_ARRAY[((chars[i + 2] & 0x0F) << 1) + (chars[i + 3] >> 7)];
			encodedBytes[k + 5] = ENCODE_ARRAY[((chars[i + 3] & 0x7F) >> 2)];
			encodedBytes[k + 6] = ENCODE_ARRAY[((chars[i + 3] & 0x03) << 3)];
			if (usePadding) {
				encodedBytes[k + 7] = PADDING_CHAR;
			}
		}

		return new String(encodedBytes);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see org.antfarmer.ejce.encoder.TextEncoder#decode(java.lang.String)
	 */
	public byte[] decode(final String text) {
		if (text == null)
			return null;

		// cleanup input string
		String encodedText = WHITE_SPACE_PATTERN.matcher(text).replaceAll("");
		int originalSize = encodedText.length();
		if (originalSize < 1) {
			return new byte[0];
		}
		if (usePadding && originalSize % 8 != 0) {
			throw new IllegalArgumentException("Encoded string does not match Base-32 format with padding.");
		}

		int newSize = (originalSize * 5) >> 3;
		int remainder = 8;
		if (usePadding) {
			int p = encodedText.indexOf(PADDING_CHAR);
			if (p > 0)
				newSize -= Math.round((originalSize - p) * 5 / 8.0);
		}
		else {
			int m = originalSize % 8;
			if (m > 0)
				remainder = m;
		}
		byte[] byteArr = new byte[newSize];
		originalSize -= 8;

		int i, j = 0;
		byte[] hexArr = new byte[8];
		for (i = 0; i < originalSize; i += 8) {
			for (int k = 0; k < 8; k++)
				hexArr[k] = DECODE_ARRAY[encodedText.charAt(i + k)];
			byteArr[j] = (byte) (hexArr[0] << 3);
			byteArr[j] += (hexArr[1] >> 2);
			byteArr[j + 1] = (byte) (hexArr[1] << 6);
			byteArr[j + 1] += (hexArr[2] << 1);
			byteArr[j + 1] += (hexArr[3] >> 4);
			byteArr[j + 2] = (byte) (hexArr[3] << 4);
			byteArr[j + 2] += (hexArr[4] >> 1);
			byteArr[j + 3] = (byte) (hexArr[4] << 7);
			byteArr[j + 3] += (hexArr[5] << 2);
			byteArr[j + 3] += (hexArr[6] >> 3);
			byteArr[j + 4] = (byte) (hexArr[6] << 5);
			byteArr[j + 4] += hexArr[7];
			j += 5;
		}

		for (int k = 0; k < remainder; k++)
			hexArr[k] = DECODE_ARRAY[encodedText.charAt(i + k)];
		byteArr[j] = (byte) (hexArr[0] << 3);
		byteArr[j] += (hexArr[1] >> 2);
		if (newSize > j + 1) {
			byteArr[j + 1] = (byte) (hexArr[1] << 6);
			byteArr[j + 1] += (hexArr[2] << 1);
			byteArr[j + 1] += (hexArr[3] >> 4);
		}
		if (newSize > j + 2) {
			byteArr[j + 2] = (byte) (hexArr[3] << 4);
			byteArr[j + 2] += (hexArr[4] >> 1);
		}
		if (newSize > j + 3) {
			byteArr[j + 3] = (byte) (hexArr[4] << 7);
			byteArr[j + 3] += (hexArr[5] << 2);
			byteArr[j + 3] += (hexArr[6] >> 3);
		}
		if (newSize > j + 4) {
			byteArr[j + 4] = (byte) (hexArr[6] << 5);
			byteArr[j + 4] += hexArr[7];
		}

		return byteArr;
	}

	/**
	 * Sets the usePadding value which indicates whether padding should be used for
	 * encoding/decoding data.
	 * 
	 * @param usePadding The usePadding value to set.
	 * @return this Base32Encoder
	 */
	protected Base32Encoder setUsePadding(boolean usePadding) {
		this.usePadding = usePadding;
		return this;
	}

}