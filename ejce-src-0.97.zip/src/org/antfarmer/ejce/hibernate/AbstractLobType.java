/*
 * Copyright 2006-2007 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.antfarmer.ejce.hibernate;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.GeneralSecurityException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Properties;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import org.hibernate.HibernateException;

/**
 * @author Ameer Antar
 */
public abstract class AbstractLobType extends AbstractHibernateType {

	public static final String KEY_COMPRESS_LOB = "compress";
	private static final int BUFF_SIZE = 4096;
	private static final int[] sqlTypes = {Types.BLOB};
	private boolean useCompression;

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int[] sqlTypes() {
		return sqlTypes;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void configure(final Properties parameters) {
		super.configure(parameters);
		// check if compression is enabled
		final String compressValue = parameters.getProperty(KEY_COMPRESS_LOB);
		if (compressValue == null || compressValue.trim().length() < 1) {
			return;
		}
		useCompression = compressValue.trim().toLowerCase().equals("true");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void nullSafeSet(final PreparedStatement st, final Object value, final int index)
			throws HibernateException, SQLException {
		if (value == null) {
			st.setNull(index, sqlTypes()[0]);
		}
		else {
			try {
				final byte[] enc = encryptLob(value);
				st.setBinaryStream(index, new ByteArrayInputStream(enc), enc.length);
			}
			catch (final GeneralSecurityException e) {
				throw new HibernateException("Error encrypting object.", e);
			}
			catch (final IOException e) {
				throw new HibernateException("Error encrypting object.", e);
			}
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Object nullSafeGet(final ResultSet rs, final String[] names, final Object owner)
			throws HibernateException, SQLException {
		final InputStream is = rs.getBinaryStream(names[0]);
		try {
			if (rs.wasNull()) {
				return null;
			}
			return streamToLob(decryptLob(is));
		}
		catch (final GeneralSecurityException e) {
			throw new HibernateException("Error decrypting object.", e);
		}
		catch (final IOException e) {
			throw new HibernateException("Error decrypting object.", e);
		}
	}

	protected byte[] encryptLob(final Object value) throws IOException, GeneralSecurityException, SQLException {
		final InputStream is = lobToStream(value);
		// compress
		final byte[] data = useCompression ? compressStream(is) : streamToBytes(is);
		// encrypt
		return getEncryptor().encrypt(data);
	}

	protected InputStream decryptLob(final InputStream is) throws GeneralSecurityException, IOException {
		// decrypt
		final byte[] dec = getEncryptor().decrypt(streamToBytes(is));
		// uncompress
		return useCompression ? new GZIPInputStream(new ByteArrayInputStream(dec), dec.length) : new ByteArrayInputStream(dec);
	}

	/**
	 * Converts the LOB value to an InputStream.
	 * @param value the LOB value
	 * @return the InputStream
	 * @throws SQLException an error converting the value to an InputStream
	 */
	protected abstract InputStream lobToStream(Object value) throws SQLException;

	/**
	 * Converts the InputStream to a LOB.
	 * @param is the InputStream
	 * @return the LOB
	 * @throws IOException an error converting the stream to a LOB
	 */
	protected abstract Object streamToLob(InputStream is) throws IOException;

	protected byte[] streamToBytes(final InputStream is) throws IOException {
		final ByteArrayOutputStream baos = new ByteArrayOutputStream(BUFF_SIZE);
		copyStream(is, baos);
		return baos.toByteArray();
	}

	protected byte[] compressStream(final InputStream stream) throws IOException {
		final ByteArrayOutputStream baos = new ByteArrayOutputStream(BUFF_SIZE);
		copyStream(stream, new GZIPOutputStream(baos));
		return baos.toByteArray();
	}

	protected void copyStream(final InputStream is, final OutputStream os) throws IOException {
		final byte[] buff = new byte[BUFF_SIZE];
		int read;
		try {
			while ((read = is.read(buff)) > -1) {
				os.write(buff, 0, read);
			}
		}
		finally {
			is.close();
			os.close();
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Object decrypt(final String value) throws GeneralSecurityException {
		// not used
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected String encrypt(final Object value) throws GeneralSecurityException {
		// not used
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public abstract Class<?> returnedClass();

}
